/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectofinal_grupo4;

/**
 *
 * @author Usuario
 */
public class DatosActividades {
    private String nombre;
    private long cedula;
    private String Movilizacion;
    private int numerounidad;
    private String Upc;
    private String Rutas;
    private String HoraEntrada;
    private String HoraSalida;

    public DatosActividades(String nombre, long cedula, String Movilizacion, int numerounidad, String Upc, String Rutas, String HoraEntrada, String HoraSalida) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.Movilizacion = Movilizacion;
        this.numerounidad = numerounidad;
        this.Upc = Upc;
        this.Rutas = Rutas;
        this.HoraEntrada = HoraEntrada;
        this.HoraSalida = HoraSalida;
    }
    public DatosActividades() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public long getCedula() {
        return cedula;
    }

    public void setCedula(long cedula) {
        this.cedula = cedula;
    }

    public String getMovilizacion() {
        return Movilizacion;
    }

    public void setMovilizacion(String Movilizacion) {
        this.Movilizacion = Movilizacion;
    }

    public int getNumerounidad() {
        return numerounidad;
    }

    public void setNumerounidad(int numerounidad) {
        this.numerounidad = numerounidad;
    }

    public String getUpc() {
        return Upc;
    }

    public void setUpc(String Upc) {
        this.Upc = Upc;
    }

    public String getRutas() {
        return Rutas;
    }

    public void setRutas(String Rutas) {
        this.Rutas = Rutas;
    }

    public String getHoraEntrada() {
        return HoraEntrada;
    }

    public void setHoraEntrada(String HoraEntrada) {
        this.HoraEntrada = HoraEntrada;
    }

    public String getHoraSalida() {
        return HoraSalida;
    }

    public void setHoraSalida(String HoraSalida) {
        this.HoraSalida = HoraSalida;
    }


}