/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectofinal_grupo4;

/**
 *
 * @author Usuario
 */
public class DatosPolicia extends Policia {
    private String categoria;

    public DatosPolicia(String nombre, long cedula, long celular, String fechanacimiento, String categoria) {
        super(nombre, cedula, celular, fechanacimiento);
        this.categoria = categoria;
    }

    public DatosPolicia() {
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
}