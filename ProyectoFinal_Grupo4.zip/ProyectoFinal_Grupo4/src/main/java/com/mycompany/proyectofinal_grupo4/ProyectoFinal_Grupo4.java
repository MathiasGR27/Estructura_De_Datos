package com.mycompany.proyectofinal_grupo4;

public class ProyectoFinal_Grupo4 {

    public static void main(String[] args) {
        Login login = new Login ();
        login.setVisible(true);
    } 
}
    