/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectofinal_grupo4;

/**
 *
 * @author Usuario
 */
public class DatosActividadesAdmi {
    private String nombre;
    private long cedula;
    private String horaentrada;
    private String horasalida;
    private boolean organizar;
    private boolean supervisar;
    private boolean controlarTalentoHumano;
    private boolean administrarPersonalPolicial;
    private boolean instrumentosTecnicos;
    private boolean coordinar;
    private boolean gestionar;
    private boolean ordenPublico;

    public DatosActividadesAdmi(String nombre, long cedula, String horaentrada, String horasalida, boolean organizar, boolean supervisar, boolean controlarTalentoHumano, boolean administrarPersonalPolicial, boolean instrumentosTecnicos, boolean coordinar, boolean gestionar, boolean ordenPublico) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.horaentrada = horaentrada;
        this.horasalida = horasalida;
        this.organizar = organizar;
        this.supervisar = supervisar;
        this.controlarTalentoHumano = controlarTalentoHumano;
        this.administrarPersonalPolicial = administrarPersonalPolicial;
        this.instrumentosTecnicos = instrumentosTecnicos;
        this.coordinar = coordinar;
        this.gestionar = gestionar;
        this.ordenPublico = ordenPublico;
    }

    public String gethoraentrada() {
        return horaentrada;
    }

    public void sethoraentrada(String horaentrada) {
        this.horaentrada = horaentrada;
    }

    public String gethorasalida() {
        return horasalida;
    }

    public void sethorasalida(String horasalida) {
        this.horasalida = horasalida;
    }
    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public long getCedula() {
        return cedula;
    }

    public void setCedula(long cedula) {
        this.cedula = cedula;
    }

    public boolean isOrganizar() {
        return organizar;
    }

    public void setOrganizar(boolean organizar) {
        this.organizar = organizar;
    }

    public boolean isSupervisar() {
        return supervisar;
    }

    public void setSupervisar(boolean supervisar) {
        this.supervisar = supervisar;
    }

    public boolean isControlarTalentoHumano() {
        return controlarTalentoHumano;
    }

    public void setControlarTalentoHumano(boolean controlarTalentoHumano) {
        this.controlarTalentoHumano = controlarTalentoHumano;
    }

    public boolean isAdministrarPersonalPolicial() {
        return administrarPersonalPolicial;
    }

    public void setAdministrarPersonalPolicial(boolean administrarPersonalPolicial) {
        this.administrarPersonalPolicial = administrarPersonalPolicial;
    }

    public boolean isInstrumentosTecnicos() {
        return instrumentosTecnicos;
    }

    public void setInstrumentosTecnicos(boolean instrumentosTecnicos) {
        this.instrumentosTecnicos = instrumentosTecnicos;
    }

    public boolean isCoordinar() {
        return coordinar;
    }

    public void setCoordinar(boolean coordinar) {
        this.coordinar = coordinar;
    }

    public boolean isGestionar() {
        return gestionar;
    }

    public void setGestionar(boolean gestionar) {
        this.gestionar = gestionar;
    }

    public boolean isOrdenPublico() {
        return ordenPublico;
    }

    public void setOrdenPublico(boolean ordenPublico) {
        this.ordenPublico = ordenPublico;
    }
    
}

    