/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.MongoException;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import static com.mongodb.client.model.Filters.eq;
import com.mycompany.proyectofinal_grupo4.DatosActividades;
import com.mycompany.proyectofinal_grupo4.DatosActividadesAdmi;
import com.mycompany.proyectofinal_grupo4.DatosPolicia;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import org.bson.Document;
import org.bson.types.ObjectId;

public class Conexion {

    MongoClient mongo;
    DB basedata;
    DBCollection coolletion;
    MongoCollection<Document> collection;
    String server = "localhost";
    int puerto = 27017;

    public MongoClient crearConexion() {
        MongoClient mongoC = null;
        try {
            mongoC = new MongoClient(server, puerto);
            List<String> nombreBaseDatos = mongoC.getDatabaseNames();
            //JOptionPane.showMessageDialog(null, "Conexion a Mongo exitosa");
        } catch (MongoException e) {
            JOptionPane.showMessageDialog(null, "Error de conexion a la base de datos " + e.toString());
        }
        return mongoC;
    }
    
    
    public void guardardatopolicia(DatosPolicia datopolicia) {
        MongoClient mongo = crearConexion();
        MongoDatabase database = mongo.getDatabase("SistemasPolicia");
        MongoCollection<Document> collection = database.getCollection("Policias");

        Document nuevoDocumento = new Document();
        nuevoDocumento.put("nombre", datopolicia.getNombre());
        nuevoDocumento.put("cedula", datopolicia.getCedula());
        nuevoDocumento.put("celular", datopolicia.getCelular());
        nuevoDocumento.put("fechaNacimiento", datopolicia.getFechanacimiento());
        nuevoDocumento.put("categoria", datopolicia.getCategoria()); // Agregar la categoría

        collection.insertOne(nuevoDocumento);
        JOptionPane.showMessageDialog(null, "Policía registrado en la base de datos");
    }
    
     // Método para obtener la lista de usuarios desde la base de datos
    public List<DatosPolicia> obtenerListaUsuarios() {
        try {
            MongoClient mongo = crearConexion();
            MongoDatabase database = mongo.getDatabase("SistemasPolicia");
            MongoCollection<Document> collection = database.getCollection("Policias");

            List<DatosPolicia> usuarios = new ArrayList<>();

            // Iterar sobre los documentos de la colección
            for (Document documento : collection.find()) {
                DatosPolicia usuario = new DatosPolicia();
                usuario.setNombre(documento.getString("nombre"));
                usuario.setCedula(documento.getLong("cedula"));
                usuario.setCelular(documento.getLong("celular"));
                usuario.setFechanacimiento(documento.getString("fechaNacimiento"));
                usuario.setCategoria(documento.getString("categoria"));

                usuarios.add(usuario);
            }
            return usuarios;
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>(); // Devolver lista vacía en caso de error
        }
    }


    public boolean existeUsuarioConCedula(long cedula) {
        MongoClient mongo = crearConexion();
        MongoDatabase database = mongo.getDatabase("SistemasPolicia");
        MongoCollection<Document> collection = database.getCollection("Policias");

        // Realizar una búsqueda para verificar si ya existe un usuario con la misma cédula
        Document existingUser = collection.find(eq("cedula", cedula)).first();

        cerrarConexion();

        return existingUser != null;
    }

    public List<DatosPolicia> leerPolicia() {
        MongoClient mongo = crearConexion();
        MongoDatabase database = mongo.getDatabase("SistemasPolicia");
        MongoCollection<Document> collection = database.getCollection("Policias");
        List<DatosPolicia> listaResultados = new ArrayList<>();

        try {
            for (Document documento : collection.find()) {
                String nombre = documento.getString("nombre");
                Object cedulaObject = documento.get("cedula");
                long cedula = (cedulaObject instanceof Integer) ? (long) (int) cedulaObject : (long) cedulaObject;

                Object celularObject = documento.get("celular");
                long celular = (celularObject instanceof Integer) ? (long) (int) celularObject : (long) celularObject;

                String fechaNacimiento = documento.getString("fechaNacimiento");
                String categoria = documento.getString("categoria");

                DatosPolicia policia = new DatosPolicia(nombre, cedula, celular, fechaNacimiento, categoria);
                listaResultados.add(policia);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Asegúrate de cerrar la conexión al finalizar el proceso
            cerrarConexion();
        }

        return listaResultados;
    }

    public List<DatosPolicia> buscarpoliciaPorCedula(String cedulaABuscar) {
        MongoClient mongo = crearConexion();
        MongoDatabase database = mongo.getDatabase("SistemasPolicia");
        MongoCollection<Document> collection = database.getCollection("Policias");

        // Crear un filtro para buscar por la cédula
        Document filtro = new Document("cedula", Long.parseLong(cedulaABuscar));

        // Realizar la búsqueda en la base de datos
        List<DatosPolicia> listaResultados = new ArrayList<>();
        for (Document documento : collection.find(filtro)) {
            DatosPolicia policia = new DatosPolicia();
            policia.setNombre(documento.getString("nombre"));
            policia.setCedula(documento.getLong("cedula"));
            policia.setCelular(documento.getLong("celular"));
            policia.setFechanacimiento(documento.getString("fechaNacimiento"));
            policia.setCategoria(documento.getString("categoria"));

            listaResultados.add(policia);
        }

        cerrarConexion();
        return listaResultados;
    }

    public void eliminarPolicia(String nombre) {
        MongoClient mongo = crearConexion();
        try {
            MongoDatabase database = mongo.getDatabase("SistemasPolicia");
            MongoCollection<Document> collection = database.getCollection("Policias");

            // Elimina el documento que cumple con el filtro
            collection.deleteOne(Filters.eq("nombre", nombre));
        } catch (MongoException e) {
            JOptionPane.showMessageDialog(null, "Error al eliminar el documento en la base de datos MongoDB: " + e.toString());
        } finally {
            cerrarConexion();
        }
    }

    public void actualizarDatosPolicia(String nombreAntiguo, DatosPolicia nuevoDato) {
        MongoClient mongo = crearConexion();
        MongoDatabase database = mongo.getDatabase("SistemasPolicia");
        MongoCollection<Document> collection = database.getCollection("Policias");

        try {
            // Crear un filtro para identificar el documento que se va a actualizar
            Document filtro = new Document("nombre", nombreAntiguo);

            // Crear un documento con los nuevos datos
            Document nuevosDatos = new Document();
            nuevosDatos.put("nombre", nuevoDato.getNombre());
            nuevosDatos.put("cedula", nuevoDato.getCedula());
            nuevosDatos.put("celular", nuevoDato.getCelular());
            nuevosDatos.put("fechaNacimiento", nuevoDato.getFechanacimiento());
            nuevosDatos.put("categoria", nuevoDato.getCategoria());

            // Crear un documento de actualización
            Document updateDoc = new Document("$set", nuevosDatos);

            // Actualizar el documento en la base de datos
            collection.updateOne(filtro, updateDoc);

            JOptionPane.showMessageDialog(null, "Datos del policía actualizados en la base de datos");

        } catch (MongoException e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar los datos en la base de datos MongoDB: " + e.toString());
        } finally {
            cerrarConexion();
        }
    }

    public void guardarActvpolicia(DatosActividades datopolicia, String nombre, long cedula) {
    MongoClient mongo = crearConexion();
    MongoDatabase database = mongo.getDatabase("SistemasPolicia");
    MongoCollection<Document> collection = database.getCollection("ActividadesPolicia");

    Document nuevoDocumento = new Document();
    nuevoDocumento.put("nombre", nombre);
    nuevoDocumento.put("cedula", cedula);
    nuevoDocumento.put("movilizacion", datopolicia.getMovilizacion());
    nuevoDocumento.put("numerounidad", datopolicia.getNumerounidad()); 
    nuevoDocumento.put("upc", datopolicia.getUpc());
    nuevoDocumento.put("rutas", datopolicia.getRutas());
    nuevoDocumento.put("HoraEntrada", datopolicia.getHoraEntrada());
    nuevoDocumento.put("HoraSalida", datopolicia.getHoraSalida());

    collection.insertOne(nuevoDocumento);
    JOptionPane.showMessageDialog(null, "Policía registrado en la base de datos");
}

    public void eliminarActvPolicia(String nombre) {
    MongoClient mongo = crearConexion();
    try {
        MongoDatabase database = mongo.getDatabase("SistemasPolicia");
        MongoCollection<Document> collection = database.getCollection("ActividadesPolicia");

        // Agrega un mensaje de depuración para imprimir el nombre antes de eliminar
        System.out.println("Eliminando documento con nombre: " + nombre);

        // Cambia la comparación al campo correcto (en este caso, "nombre")
        collection.deleteOne(Filters.eq("nombre", nombre));
    } catch (MongoException e) {
        JOptionPane.showMessageDialog(null, "Error al eliminar el documento en la base de datos MongoDB: " + e.toString());
    } finally {
        cerrarConexion();
    }
}
    public List<DatosActividades> leeractvPolicia() {
    MongoClient mongo = crearConexion();
    MongoDatabase database = mongo.getDatabase("SistemasPolicia");
    MongoCollection<Document> collection = database.getCollection("ActividadesPolicia");
    List<DatosActividades> listaactv = new ArrayList<>();

    try {
        for (Document documentos : collection.find()) {
            String nombre = documentos.getString("nombre");

            // Verifica si cedulaObject no es null antes de invocar longValue()
            Object cedulaObject = documentos.get("cedula");
            long cedula = (cedulaObject != null) ? ((cedulaObject instanceof Integer) ? (long) (int) cedulaObject : (long) cedulaObject) : 0;

            String movilizacion = documentos.getString("movilizacion");
            String upc = documentos.getString("upc");
            String rutas = documentos.getString("rutas");
            int numerounidad = documentos.getInteger("numerounidad");
            String horaentrada = documentos.getString("HoraEntrada");
            String horasalida = documentos.getString("HoraSalida");

            DatosActividades policia = new DatosActividades(nombre, cedula, movilizacion,numerounidad, upc, rutas,horaentrada,horasalida);
            listaactv.add(policia);
        }
    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        // Asegúrate de cerrar la conexión al finalizar el proceso
        cerrarConexion();
    }

    return listaactv;
}

    public boolean usuarioTieneActividades(long cedula) {
        MongoClient mongo = crearConexion();
        MongoDatabase database = mongo.getDatabase("SistemasPolicia");
        MongoCollection<Document> collection = database.getCollection("ActividadesPolicia");

        try {
            // Buscar el usuario por su cédula
            Document filtro = new Document("cedula", cedula);
            Document usuario = collection.find(filtro).first();

            // Verificar si el usuario existe (es decir, tiene actividades)
            return usuario != null;
        } catch (MongoException e) {
            JOptionPane.showMessageDialog(null, "Error al verificar las actividades del usuario en la base de datos MongoDB: " + e.toString());
            return false;
        } finally {
            cerrarConexion();
        }
    }

    public List<DatosActividades> buscaractvpoliciaPorCedula(String cedulaABuscar) {
        MongoClient mongo = crearConexion();
        MongoDatabase database = mongo.getDatabase("SistemasPolicia");
        MongoCollection<Document> collection = database.getCollection("ActividadesPolicia");

        // Crear un filtro para buscar por la cédula
        Document filtro = new Document("cedula", Long.parseLong(cedulaABuscar));

        // Realizar la búsqueda en la base de datos
        List<DatosActividades> listaResultadosactv = new ArrayList<>();
        for (Document documento : collection.find(filtro)) {
            DatosActividades actividades = new DatosActividades();
            actividades.setRutas(documento.getString("Rutas"));
            actividades.setUpc(documento.getString("Upc"));
            
            listaResultadosactv.add(actividades);
        }

        cerrarConexion();
        return listaResultadosactv;
    }
    public void guardarActvAdmi(DatosActividadesAdmi datosAdmi, String nombre, long cedula) {
    MongoClient mongo = crearConexion();
    MongoDatabase database = mongo.getDatabase("SistemasPolicia");
    MongoCollection<Document> collection = database.getCollection("ActividadesAdministrativos");

    Document nuevoDocumento = new Document();
    nuevoDocumento.put("nombre", nombre);
    nuevoDocumento.put("cedula", cedula);
    nuevoDocumento.put("horaEntrada", datosAdmi.gethoraentrada());
    nuevoDocumento.put("horaSalida", datosAdmi.gethorasalida());
    nuevoDocumento.put("organizar", datosAdmi.isOrganizar());
    nuevoDocumento.put("supervisar", datosAdmi.isSupervisar());
    nuevoDocumento.put("controlarTalentoHumano", datosAdmi.isControlarTalentoHumano());
    nuevoDocumento.put("administrarPersonalPolicial", datosAdmi.isAdministrarPersonalPolicial());
    nuevoDocumento.put("instrumentosTecnicos", datosAdmi.isInstrumentosTecnicos());
    nuevoDocumento.put("coordinar", datosAdmi.isCoordinar());
    nuevoDocumento.put("gestionar", datosAdmi.isGestionar());
    nuevoDocumento.put("ordenPublico", datosAdmi.isOrdenPublico());

    collection.insertOne(nuevoDocumento);
    JOptionPane.showMessageDialog(null, "Datos guardados en la base de datos");
}

public List<DatosActividadesAdmi> leeractvAdmi() {
    MongoClient mongo = crearConexion();
    MongoDatabase database = mongo.getDatabase("SistemasPolicia");
    MongoCollection<Document> collection = database.getCollection("ActividadesAdministrativos");
    List<DatosActividadesAdmi> listaactvadmi = new ArrayList<>();

    try {
        for (Document documento : collection.find()) {
            String nombre = documento.getString("nombre");

            // Verifica si cedulaObject no es null antes de invocar longValue()
            Object cedulaObject = documento.get("cedula");
            long cedula = (cedulaObject != null) ? ((cedulaObject instanceof Integer) ? (long) (int) cedulaObject : (long) cedulaObject) : 0;
            
            String horaentrada = documento.getString("horaEntrada");
            String horasalida = documento.getString("horaSalida");

            // Recupera los valores booleanos verificando nulidad
            boolean organizar = Boolean.TRUE.equals(documento.getBoolean("organizar"));
            boolean supervisar = Boolean.TRUE.equals(documento.getBoolean("supervisar"));
            boolean controlarTalentoHumano = Boolean.TRUE.equals(documento.getBoolean("controlarTalentoHumano"));
            boolean administrarPersonalPolicial = Boolean.TRUE.equals(documento.getBoolean("administrarPersonalPolicial"));
            boolean instrumentosTecnicos = Boolean.TRUE.equals(documento.getBoolean("instrumentosTecnicos"));
            boolean coordinar = Boolean.TRUE.equals(documento.getBoolean("coordinar"));
            boolean gestionar = Boolean.TRUE.equals(documento.getBoolean("gestionar"));
            boolean ordenPublico = Boolean.TRUE.equals(documento.getBoolean("ordenPublico"));

            DatosActividadesAdmi actividadesAdmi = new DatosActividadesAdmi(
                    nombre, cedula, horaentrada, horasalida, organizar, supervisar, controlarTalentoHumano,
                    administrarPersonalPolicial, instrumentosTecnicos, coordinar, gestionar, ordenPublico);

            listaactvadmi.add(actividadesAdmi);
        }
    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        cerrarConexion();
    }

    return listaactvadmi;
}
    
    public void eliminarActAdmi(String nombre) {
    MongoClient mongo = crearConexion();
    try {
        MongoDatabase database = mongo.getDatabase("SistemasPolicia");
        MongoCollection<Document> collection = database.getCollection("ActividadesAdministrativos");

        // Agrega un mensaje de depuración para imprimir el nombre antes de eliminar
        System.out.println("Eliminando documento con nombre: " + nombre);

        // Cambia la comparación al campo correcto (en este caso, "nombre")
        collection.deleteOne(Filters.eq("nombre", nombre));
    } catch (MongoException e) {
        JOptionPane.showMessageDialog(null, "Error al eliminar el documento en la base de datos MongoDB: " + e.toString());
    } finally {
        cerrarConexion();
    }
}
   
  public boolean usuarioTieneActividadesadmi(long cedula) {
    MongoClient mongo = crearConexion();
    MongoDatabase database = mongo.getDatabase("SistemasPolicia");
    MongoCollection<Document> collection = database.getCollection("ActividadesAdministrativos");

    try {
        // Buscar el usuario por su cédula
        Document filtro = new Document("cedula", cedula);
        Document usuario = collection.find(filtro).first();

        // Verificar si el usuario existe (es decir, tiene actividades)
        return usuario != null;
    } catch (MongoException e) {
        JOptionPane.showMessageDialog(null, "Error al verificar las actividades del usuario en la base de datos MongoDB: " + e.toString());
        return false;
    } finally {
        cerrarConexion();
    }
}
    public void cerrarConexion() {
        if (mongo != null) {
            mongo.close();
            JOptionPane.showMessageDialog(null, "Conexión cerrada");
        }
    }
}
