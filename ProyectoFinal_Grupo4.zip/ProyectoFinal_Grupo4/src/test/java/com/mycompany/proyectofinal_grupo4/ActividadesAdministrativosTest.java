/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.proyectofinal_grupo4;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Usuario
 */
public class ActividadesAdministrativosTest {
    
    public ActividadesAdministrativosTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of setNombreYCedula method, of class ActividadesAdministrativos.
     */
    @Test
    public void testSetNombreYCedula() {
        System.out.println("setNombreYCedula");
        String nombre = "";
        long cedula = 0L;
        ActividadesAdministrativos instance = new ActividadesAdministrativos();
        instance.setNombreYCedula(nombre, cedula);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of AgregarDatos method, of class ActividadesAdministrativos.
     */
    @Test
    public void testAgregarDatos() {
        System.out.println("AgregarDatos");
        ActividadesAdministrativos instance = new ActividadesAdministrativos();
        boolean expResult = false;
        boolean result = instance.AgregarDatos();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of eliminaractvDatos method, of class ActividadesAdministrativos.
     */
    @Test
    public void testEliminaractvDatos() {
        System.out.println("eliminaractvDatos");
        ActividadesAdministrativos instance = new ActividadesAdministrativos();
        boolean expResult = false;
        boolean result = instance.eliminaractvDatos();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of limpiarDatos method, of class ActividadesAdministrativos.
     */
    @Test
    public void testLimpiarDatos() {
        System.out.println("limpiarDatos");
        ActividadesAdministrativos instance = new ActividadesAdministrativos();
        boolean expResult = false;
        boolean result = instance.limpiarDatos();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of cargarDatosactvEnTabla method, of class ActividadesAdministrativos.
     */
    @Test
    public void testCargarDatosactvEnTabla() {
        System.out.println("cargarDatosactvEnTabla");
        ActividadesAdministrativos instance = new ActividadesAdministrativos();
        boolean expResult = false;
        boolean result = instance.cargarDatosactvEnTabla();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class ActividadesAdministrativos.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        ActividadesAdministrativos.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
