/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.proyectofinal_grupo4;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.concurrent.CountDownLatch;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Usuario
 */
public class ActividadesPoliciaTest {

    public ActividadesPoliciaTest() {
    }

    @BeforeAll
    public static void setUpClass() {
    }

    @AfterAll
    public static void tearDownClass() {
    }

    @BeforeEach
    public void setUp() {
    }

    @AfterEach
    public void tearDown() {
    }

    @Test
    void testSetNombreYCedula() {
        // Configurar datos de prueba
        ActividadesPolicia instance = new ActividadesPolicia();
        String nombre = "NombrePrueba";
        instance.setNombre(nombre);
        instance.setCedula(235002514);

        // Verificar que el nombre no sea null
        assertNotNull(instance.getNombre(), "El nombre no debería ser null");

        // Otras aserciones si es necesario
        assertEquals("NombrePrueba", instance.getNombre(), "El nombre no coincide");
        assertEquals(235002514, instance.getCedula(), "La cédula no coincide");
    }

    @Test
    public void testAgregarDatos() {
        // Configuración de datos de prueba
        String nombre = "John Doe";
        long cedula = 123456789;
        String unidad = "Unidad1";

        ActividadesPolicia actividadesPolicia = new ActividadesPolicia();

        // Configurar los campos en la interfaz de usuario si es necesario
        actividadesPolicia.setNombre(nombre);
        actividadesPolicia.setCedula(cedula);

        // Realizar la acción que se va a probar
        boolean resultado = actividadesPolicia.AgregarDatos();

        // Verificar el resultado
        assertTrue(resultado);
        // Agrega más aserciones según sea necesario

        // También puedes verificar el estado esperado después de agregar datos
        assertEquals(nombre, actividadesPolicia.getNombre());
        assertEquals(cedula, actividadesPolicia.getCedula());
    }

    @Test
    public void testEliminaractvDatos() {
        // Configurar datos de prueba en la tabla o en la interfaz de usuario si es necesario

        ActividadesPolicia actividadesPolicia = new ActividadesPolicia();
        // Realizar la acción que se va a probar
        boolean resultado = actividadesPolicia.eliminaractvDatos();

        // Verificar el resultado
        assertTrue(resultado, "EliminaractvDatos debería devolver true");
        // Agrega más aserciones según sea necesario
    }

    @Test
    public void testLimpiarDatos() {
        // Configurar datos de prueba en la tabla o en la interfaz de usuario si es necesario

        ActividadesPolicia actividadesPolicia = new ActividadesPolicia();
        // Realizar la acción que se va a probar
        boolean resultado = actividadesPolicia.limpiarDatos();

        // Verificar el resultado
        assertTrue(resultado, "LimpiarDatos debería devolver true");
        // Agrega más aserciones según sea necesario
    }

    @Test
    public void testCargarDatosactvEnTabla() {
        System.out.println("cargarDatosactvEnTabla");
        ActividadesPolicia instance = new ActividadesPolicia();
        // Puedes ajustar los valores esperados y las condiciones según la lógica de tu aplicación
        assertTrue(instance.cargarDatosactvEnTabla(), "CargarDatosactvEnTabla debería devolver true");
    }

    /**
     * Test of main method, of class ActividadesPolicia.
     */
    @Test
    public void testMain() {
        System.out.println("testMain");

        CountDownLatch latch = new CountDownLatch(1);

        SwingUtilities.invokeLater(() -> {
            ActividadesPolicia actv = new ActividadesPolicia();
            actv.setVisible(true);

            actv.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosed(WindowEvent e) {
                    // La interfaz se ha cerrado, reducimos el recuento del latch
                    latch.countDown();
                }
            });
        });

        try {
            // Espera hasta que el usuario cierre la interfaz
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
