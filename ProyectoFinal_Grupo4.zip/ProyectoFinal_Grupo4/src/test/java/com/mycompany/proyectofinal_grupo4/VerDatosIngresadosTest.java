/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.proyectofinal_grupo4;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.concurrent.CountDownLatch;
import javax.swing.SwingUtilities;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Usuario
 */
public class VerDatosIngresadosTest {
    
    public VerDatosIngresadosTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Prueba del método buscarDatos, de la clase VerDatosIngresados.
     */
    @Test
    public void testBuscarDatos() {
        System.out.println("testBuscarDatos");
        VerDatosIngresados instance = new VerDatosIngresados();
        boolean expResult = false; // 
        boolean result = instance.buscarDatos();
        //llama al método y luego verifica que algún estado ha cambiado
        assertEquals(expResult, result);
    }

    /**
     * Prueba del método main, de la clase VerDatosIngresados.
     * Este método generalmente no se prueba directamente porque está relacionado con la interfaz gráfica.
     */
    @Test
    public void testMain() {
         System.out.println("testMain");

        CountDownLatch latch = new CountDownLatch(1);

        SwingUtilities.invokeLater(() -> {
            VerDatosIngresados ver = new VerDatosIngresados();
            ver.setVisible(true);

            ver.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosed(WindowEvent e) {
                    // La interfaz se ha cerrado, reducimos el recuento del latch
                    latch.countDown();
                }
            });
        });

        try {
            // Espera hasta que el usuario cierre la interfaz
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}