/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.proyectofinal_grupo4;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Usuario
 */
public class ReporteDiarioTest {
    
    public ReporteDiarioTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of generarReporte method, of class ReporteDiario.
     */
    @Test
    public void testGenerarReporte() {
        System.out.println("generarReporte");
        ReporteDiario instance = new ReporteDiario();
        boolean expResult = false;
        boolean result = instance.generarReporte();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of generarInformeGeneral method, of class ReporteDiario.
     */
    @Test
    public void testGenerarInformeGeneral() {
        System.out.println("generarInformeGeneral");
        ReporteDiario instance = new ReporteDiario();
        boolean expResult = false;
        boolean result = instance.generarInformeGeneral();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of buscarDatos method, of class ReporteDiario.
     */
    @Test
    public void testBuscarDatos() {
        System.out.println("buscarDatos");
        ReporteDiario instance = new ReporteDiario();
        boolean expResult = false;
        boolean result = instance.buscarDatos();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class ReporteDiario.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        ReporteDiario.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
