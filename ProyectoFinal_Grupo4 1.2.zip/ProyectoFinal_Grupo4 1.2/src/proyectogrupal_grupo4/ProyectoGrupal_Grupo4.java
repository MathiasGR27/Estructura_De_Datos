/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyectogrupal_grupo4;

/**
 *
 * @author Usuario
 */
public class ProyectoGrupal_Grupo4 {


    public static void main(String[] args) {
        LoginPolicia login = new LoginPolicia();
        login.setVisible(true);
        
    }
    
}
