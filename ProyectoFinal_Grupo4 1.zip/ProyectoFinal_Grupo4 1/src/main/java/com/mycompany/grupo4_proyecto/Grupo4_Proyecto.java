package com.mycompany.grupo4_proyecto;

public class Grupo4_Proyecto {

    public static void main(String[] args) {
        LoginPolicia login = new LoginPolicia();
        login.setVisible(true);
    }
}
