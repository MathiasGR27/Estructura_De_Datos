/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labpilascolaslistas_gualpamathias;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

/**
 *
 * @author ESPE
 */
public class ManejoTareas {
    private List<Tareas> tareasPendientes = new ArrayList<>();
    private List<Tareas> tareasCompletadas = new ArrayList<>();
    private Stack<Tareas> historialDeshacer = new Stack<>();
    private Queue<Tareas> recordatorios = new LinkedList<>();

    public void agregarTareas(String descripcion,String Fecha) {
        
        int id = tareasPendientes.size() + 1;
        Tareas nuevaTarea = new Tareas(id, descripcion,Fecha);
        tareasPendientes.add(nuevaTarea);
        System.out.println("Tarea agregada: " + nuevaTarea.descripcion);
    }
    
    public void marcarComoCompletada(int idTarea) {
        Tareas tarea = buscarTareaPorId(tareasPendientes, idTarea);

        if (tarea != null && !tarea.completada) {
            tarea.completada = true;
            tareasCompletadas.add(tarea);
            historialDeshacer.push(tarea);
            tareasPendientes.remove(tarea);
            System.out.println("Tarea marcada como completada: " + tarea.descripcion);
        } else {
            System.out.println("La tarea no existe o ya está completada.");
        }
    }
    
    private Tareas buscarTareaPorId(List<Tareas> listaTareas, int id) {
        for (Tareas tarea : listaTareas) {
            if (tarea.id == id) {
                return tarea;
            }
        }
        return null;
    }

    public void deshacerUltimaCompletada() {
        if (!historialDeshacer.isEmpty()) {
            Tareas tareaDeshacer = historialDeshacer.pop();
            tareaDeshacer.completada = false;
            tareasPendientes.add(tareaDeshacer);
            tareasCompletadas.remove(tareaDeshacer);
            System.out.println("Se deshizo la última tarea completada: " + tareaDeshacer.descripcion);
        } else {
            System.out.println("No hay tareas completadas para deshacer.");
        }
    }
       public void agregarAReminderQueue(String descripcion, String Fecha) {
        Tareas nuevaTarea = new Tareas(-1, descripcion, Fecha);
        recordatorios.add(nuevaTarea);
        System.out.println("Recordatorio agregado: " + nuevaTarea.descripcion);
    }

    public void visualizarTareasPendientes() {
        System.out.println("Tareas Pendientes:");
        for (Tareas tarea : tareasPendientes) {
            System.out.println("ID: " + tarea.id + " Descripción: " + tarea.descripcion);
        }
    }

    
    public void visualizarTareasCompletadas() {
        System.out.println("Tareas Completadas:");
        for (Tareas tarea : tareasCompletadas) {
            System.out.println("ID: " + tarea.id + " Descripción: " + tarea.descripcion);
        }
    }

    public void visualizarTareasVencidas() {
    Scanner scanner = new Scanner(System.in);

    System.out.println("Ingrese la fecha para verificar tareas vencidas :");
    String fechaStr = scanner.nextLine();

    System.out.println("Tareas Vencidas:");
    for (Tareas tarea : recordatorios) {
        String fechaVencimientoStr = tarea.getFecha();

        // Muestra todas las tareas sin validar la fecha
        System.out.println("Descripción: " + tarea.descripcion + " - Fecha de vencimiento: " + fechaVencimientoStr);
    }
}

}
