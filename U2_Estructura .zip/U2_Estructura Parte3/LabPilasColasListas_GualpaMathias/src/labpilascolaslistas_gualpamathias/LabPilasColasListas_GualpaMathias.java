/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package labpilascolaslistas_gualpamathias;

import java.util.Scanner;


public class LabPilasColasListas_GualpaMathias {

    public static void main(String[] args) {
               ManejoTareas tarea = new ManejoTareas();
        Scanner scanner = new Scanner(System.in);
        int opc;

        // Generamos un menu
        do {
            System.out.print("\nMenu");
            System.out.print("\n1 Agregar una nueva tarea a la lista de tareas pendientes");
            System.out.print("\n2 Visualizar todas las tareas pendientes ");
            System.out.print("\n3 Marcar una tarea como completada ");
            System.out.print("\n4 Deshacer la última tarea completada utilizando la pila");
            System.out.print("\n5 Agregar una tarea a la cola de recordatorios");
            System.out.print("\n6 Visualizar todas las tareas completadas");
            System.out.print("\n7 Visualizar las tareas vencidas de la cola de recordatorios");
            System.out.print("\n8 Salir");
            System.out.print("\nSeleccione una opcion : ");
            opc = scanner.nextInt();

            switch (opc) {
                case 1:
                    System.out.println("Ingrese la descripción de la nueva tarea:");
                    scanner.nextLine(); // Consumir el salto de línea pendiente
                    String descripcion = scanner.nextLine();
                    String Fechas = scanner.nextLine();
                    tarea.agregarTareas(descripcion,Fechas);
                    break;

                case 2:
                    tarea.visualizarTareasPendientes();
                    break;

                case 3:
                    System.out.println("Ingrese el ID de la tarea a marcar como completada:");
                    int idCompletada = scanner.nextInt();
                    tarea.marcarComoCompletada(idCompletada);
                    break;

                case 4:
                    tarea.deshacerUltimaCompletada();    
                    break;

                case 5:
                    System.out.println("Ingrese la descripción de la tarea para el recordatorio:");
                    scanner.nextLine(); // Consumir el salto de línea pendiente
                    String descripcionRecordatorio = scanner.nextLine();
                    System.out.println("Ingrese la fecha de vencimiento (cualquier formato):");
                    String Fecha = scanner.nextLine();
                    tarea.agregarAReminderQueue(descripcionRecordatorio, Fecha);
                    break;

                case 6:
                    tarea.visualizarTareasCompletadas();
                    break;

                case 7:
                    tarea.visualizarTareasVencidas();
                    break;
                    
                case 8:
                    System.out.println("Saliendo del programa ");
                    break;

                default:
                    System.out.println("Opción no válida");
            }

        } while (opc != 8);
    }
}

