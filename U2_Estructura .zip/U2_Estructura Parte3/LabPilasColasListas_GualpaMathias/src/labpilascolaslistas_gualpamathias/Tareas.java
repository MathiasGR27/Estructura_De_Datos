/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package labpilascolaslistas_gualpamathias;

/**
 *
 * @author ESPE
 */
public class Tareas {
    int id;
    String Fecha;
    String descripcion;
    boolean completada;

    public Tareas(int id, String descripcion, String Fecha) {
        this.id = id;
        this.descripcion = descripcion;
        this.Fecha=Fecha;
        this.completada = false;
    }

    public String getFecha() {
        return Fecha;
    }
    
    
}


