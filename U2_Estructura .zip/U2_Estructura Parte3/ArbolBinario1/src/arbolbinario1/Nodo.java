/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arbolbinario1;

/**
 *
 * @author gisse
 */
public class Nodo {
    int valor;
    Nodo izquierda;
    Nodo derecha;
    public Nodo(int valor) {
    this.valor = valor;
    this.izquierda = null;
}}