/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package u2practica3_ordenar;

import java.util.Scanner;

public class U2Practica3_Ordenar {

    public static void main(String[] args) {   
        MenuOpciones menu = new MenuOpciones();
        menu.menu();
    }
       
}

 