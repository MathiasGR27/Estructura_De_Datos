/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arbolbinario2_gualpamathia;

import java.util.Scanner;

/**
 *
 * @author ESPE
 */
public class ArbolBinario2_GualpaMathia {

    private NodoArbol arbol = null;
 public static void main(String[] args) {
 GestorArbol gestor = new GestorArbol();
 gestor.ejecutarMenuArbol();
 }
//
}