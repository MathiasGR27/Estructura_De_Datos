/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestiondenotasestudiantes;

/**
 *
 * @author Usuario
 */
public class matriculas {
    private int nrcMaterias;
    private String semestre;
    private String nombreMateria;
    private String nombreIngeniero;

    public matriculas() {
        // Constructor vacío
    }

    public matriculas(int nrcMaterias, String semestre, String nombreMateria, String nombreIngeniero) {
        this.nrcMaterias = nrcMaterias;
        this.semestre = semestre;
        this.nombreMateria = nombreMateria;
        this.nombreIngeniero = nombreIngeniero;
    }

    public int getNrcMaterias() {
        return nrcMaterias;
    }

    public void setNrcMaterias(int nrcMaterias) {
        this.nrcMaterias = nrcMaterias;
    }

    public String getSemestre() {
        return semestre;
    }

    public void setSemestre(String semestre) {
        this.semestre = semestre;
    }

    public String getNombreMateria() {
        return nombreMateria;
    }

    public void setNombreMateria(String nombreMateria) {
        this.nombreMateria = nombreMateria;
    }

    public String getNombreIngeniero() {
        return nombreIngeniero;
    }

    public void setNombreIngeniero(String nombreIngeniero) {
        this.nombreIngeniero = nombreIngeniero;
    }
    
    
}
