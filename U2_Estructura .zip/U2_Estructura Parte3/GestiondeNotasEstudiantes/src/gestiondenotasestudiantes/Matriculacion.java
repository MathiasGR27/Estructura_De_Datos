package gestiondenotasestudiantes;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;

public class Matriculacion extends JFrame {

    private JTextField NRcMateriasTextField;
    private JTextField semestreTextField;
    private JTextField nombreMateriaTextField;
    private JTextField nombreIngenieroTextField;
    private DefaultTableModel modeloTabla;

    public Matriculacion() {
        // Configuración de la ventana
        setTitle("Matriculación");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Crear componentes de la interfaz
        NRcMateriasTextField = new JTextField(10);
        semestreTextField = new JTextField(10);
        nombreMateriaTextField = new JTextField(10);
        nombreIngenieroTextField = new JTextField(10);
        JButton guardarButton = new JButton("Guardar");
        JButton eliminarButton = new JButton("Eliminar");
        JButton actualizarButton = new JButton("Actualizar");
        JButton salirButton = new JButton("Salir");

        // Configurar la tabla
        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("NRC de la Materia");
        modeloTabla.addColumn("Semestre");
        modeloTabla.addColumn("Materia");
        modeloTabla.addColumn("Ingeniero ");

        JTable tabla = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tabla);

        // Configurar colores para botones
        Color colorInicial = new Color(173, 216, 230); // Celeste
        Color colorResaltado = new Color(0, 255, 255); // Azul

        guardarButton.setBackground(colorInicial);
        eliminarButton.setBackground(colorInicial);
        actualizarButton.setBackground(colorInicial);
        salirButton.setBackground(colorInicial);

        // Configurar eventos para cambiar el color al pasar el mouse
        MouseAdapter colorChangeAdapter = new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ((JButton) evt.getSource()).setBackground(colorResaltado);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                ((JButton) evt.getSource()).setBackground(colorInicial);
            }
        };

        guardarButton.addMouseListener(colorChangeAdapter);
        eliminarButton.addMouseListener(colorChangeAdapter);
        actualizarButton.addMouseListener(colorChangeAdapter);
        salirButton.addMouseListener(colorChangeAdapter);

        // Configurar eventos para los botones
        guardarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obtener los valores de los campos
                int nrcMaterias = Integer.parseInt(NRcMateriasTextField.getText().trim());
                String semestre = semestreTextField.getText().trim();
                String nombreMateria = nombreMateriaTextField.getText().trim();
                String nombreIngeniero = nombreIngenieroTextField.getText().trim();
                
                if(modeloTabla.getRowCount() >= 6){
                    JOptionPane.showMessageDialog(null, "Ya ha alcanzado el límite de 6 materias matriculadas.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }else{
                    // Crear una instancia de Matriculacion y establecer los valores
                matriculas matriculacion = new matriculas(nrcMaterias, semestre, nombreMateria, nombreIngeniero);

                // Agregar información a la tabla (o realizar acciones adicionales según sea necesario)
                Object[] fila = {matriculacion.getNrcMaterias(), matriculacion.getSemestre(), matriculacion.getNombreMateria(), matriculacion.getNombreIngeniero()};
                modeloTabla.addRow(fila);

                // Limpiar los campos después de la inserción (opcional)
                NRcMateriasTextField.setText("");
                semestreTextField.setText("");
                nombreMateriaTextField.setText("");
                nombreIngenieroTextField.setText("");
                }  
            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tabla.getSelectedRow();

                if (filaSeleccionada != -1) {
                    modeloTabla.removeRow(filaSeleccionada);
                } else {
                    JOptionPane.showMessageDialog(null, "Seleccione una fila para eliminar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });

        actualizarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tabla.getSelectedRow();

                if (filaSeleccionada != -1) {
                    // Obtener los valores de los campos
                    int numMaterias = Integer.parseInt(NRcMateriasTextField.getText().trim());
                    String semestre = semestreTextField.getText().trim(); // Cambiado a String
                    String nombreMateria = nombreMateriaTextField.getText().trim();
                    String nombreIngeniero = nombreIngenieroTextField.getText().trim();

                    // Actualizar la fila en la tabla
                    modeloTabla.setValueAt(numMaterias, filaSeleccionada, 0);
                    modeloTabla.setValueAt(semestre, filaSeleccionada, 1);
                    modeloTabla.setValueAt(nombreMateria, filaSeleccionada, 2);
                    modeloTabla.setValueAt(nombreIngeniero, filaSeleccionada, 3);

                    // Limpiar los campos después de la actualización (opcional)
                    NRcMateriasTextField.setText("");
                    semestreTextField.setText("");
                    nombreMateriaTextField.setText("");
                    nombreIngenieroTextField.setText("");
                } else {
                    JOptionPane.showMessageDialog(null, "Seleccione una fila para actualizar.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });

        salirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                MenuFormularios.obtenerInstancia().mostrarVentana(); // Mostrar la ventana de MenuFormularios
            }
        });

        // Configurar el diseño de la interfaz
        JPanel panel = new JPanel(new GridLayout(7, 2, 5, 5));
        panel.add(new JLabel("NRC de la Materia :"));
        panel.add(NRcMateriasTextField);
        panel.add(new JLabel("Semestre:"));
        panel.add(semestreTextField);
        panel.add(new JLabel("Nombre de la Materia:"));
        panel.add(nombreMateriaTextField);
        panel.add(new JLabel("Nombre del Ingeniero:"));
        panel.add(nombreIngenieroTextField);
        panel.add(guardarButton);
        panel.add(eliminarButton);
        panel.add(actualizarButton);
        panel.add(salirButton);

        // Agregar el panel y el JScrollPane a la ventana
        add(panel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
    }
}