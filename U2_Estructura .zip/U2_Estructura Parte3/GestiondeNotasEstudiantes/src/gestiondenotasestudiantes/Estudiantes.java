/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestiondenotasestudiantes;


public class Estudiantes implements Comparable<Estudiantes> {
    private String nombre;
    private String apellido;
    private String asistencia;  // Corregido el nombre
    private double notaPrimerParcial;
    private double notaSegundoParcial;
    private double notaTercerParcial;
    private double promedio;

    public Estudiantes() {
    }

    public Estudiantes(String nombre, String apellido, String asistencia, double notaPrimerParcial, double notaSegundoParcial, double notaTercerParcial, double promedio) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.asistencia = asistencia;
        this.notaPrimerParcial = notaPrimerParcial;
        this.notaSegundoParcial = notaSegundoParcial;
        this.notaTercerParcial = notaTercerParcial;
        this.promedio = promedio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getAsistencia() {
        return asistencia;
    }

    public void setAsistencia(String asistencia) {
        this.asistencia = asistencia;
    }

    public double getNotaPrimerParcial() {
        return notaPrimerParcial;
    }

    public void setNotaPrimerParcial(double notaPrimerParcial) {
        this.notaPrimerParcial = notaPrimerParcial;
    }

    public double getNotaSegundoParcial() {
        return notaSegundoParcial;
    }

    public void setNotaSegundoParcial(double notaSegundoParcial) {
        this.notaSegundoParcial = notaSegundoParcial;
    }

    public double getNotaTercerParcial() {
        return notaTercerParcial;
    }

    public void setNotaTercerParcial(double notaTercerParcial) {
        this.notaTercerParcial = notaTercerParcial;
    }

    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(double promedio) {
        this.promedio = promedio;
    }
    
     @Override
    public int compareTo(Estudiantes otroEstudiante) {
        return Double.compare(this.getPromedio(), otroEstudiante.getPromedio());
    }
}

