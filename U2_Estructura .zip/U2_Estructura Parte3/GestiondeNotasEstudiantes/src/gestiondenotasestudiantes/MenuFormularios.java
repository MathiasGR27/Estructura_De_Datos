package gestiondenotasestudiantes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuFormularios {
    private static MenuFormularios instancia; // Instancia única de la clase
    private JFrame frame;

    private MenuFormularios() {
        // Constructor privado para evitar la creación de nuevas instancias
        inicializar();
    }

    private void inicializar() {
        frame = new JFrame("Menú Principal");
        frame.setSize(900, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Crea un JLabel con una imagen de fondo
        ImageIcon imagenFondo = new ImageIcon("G:\\Mathias\\GestiondeNotasEstudiantes\\fondo.jpg");
        Image img = imagenFondo.getImage();
        Image imgEscalada = img.getScaledInstance(frame.getWidth(), frame.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon imagenFondoEscalada = new ImageIcon(imgEscalada);

        JLabel fondo = new JLabel(imagenFondoEscalada);
        fondo.setLayout(new GridBagLayout());

        // Crea un JPanel para contener los componentes sobre la imagen de fondo
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE); // Establece el color de fondo del panel

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(3, 3, 3, 3); // Espaciado entre componentes

        // Etiqueta y botón para el botón Periodo
        JLabel etiquetaPeriodo = new JLabel("Registro de Períodos");
        etiquetaPeriodo.setForeground(Color.BLACK);
        etiquetaPeriodo.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(etiquetaPeriodo, gbc);

        JButton botonPeriodo = new JButton(new ImageIcon("G:/Mathias/GestiondeNotasEstudiantes/periodo.png"));
        botonPeriodo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ocultarVentana();
                Periodo periodo = new Periodo();
                periodo.setVisible(true);
            }
        });
        botonPeriodo.setVerticalTextPosition(SwingConstants.BOTTOM);
        botonPeriodo.setHorizontalTextPosition(SwingConstants.CENTER);
        botonPeriodo.setPreferredSize(new Dimension(200, 100)); // Ajusta el tamaño
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(botonPeriodo, gbc);

        // Etiqueta y botón para el botón GestiondeNotasEstudiantes
        JLabel etiquetaGestionNotas = new JLabel("Registro de Notas al sistema");
        etiquetaGestionNotas.setForeground(Color.BLACK);
        etiquetaGestionNotas.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridx = 0;
        gbc.gridy = 5;
        panel.add(etiquetaGestionNotas, gbc);

        JButton botonGestionNotas = new JButton(new ImageIcon("G:/Mathias/GestiondeNotasEstudiantes/gestionotas.png"));
        botonGestionNotas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ocultarVentana();
                GestiondeNotasEstudiantes gestionNotas = new GestiondeNotasEstudiantes();
                gestionNotas.setVisible(true);
            }
        });
        botonGestionNotas.setVerticalTextPosition(SwingConstants.BOTTOM);
        botonGestionNotas.setHorizontalTextPosition(SwingConstants.CENTER);
        botonGestionNotas.setPreferredSize(new Dimension(200, 100)); // Ajusta el tamaño
        gbc.gridx = 0;
        gbc.gridy = 6;
        panel.add(botonGestionNotas, gbc);

        // Etiqueta y botón para el tercer botón adicional
        JLabel materia = new JLabel("Matriculacion de Materias ");
        materia.setForeground(Color.BLACK);
        materia.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(materia, gbc);

        JButton materias = new JButton(new ImageIcon("G:/Mathias/GestiondeNotasEstudiantes/materia.png"));
        materias.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ocultarVentana();
                Matriculacion matri = new Matriculacion();
                matri.setVisible(true);
            }
        });
        materias.setVerticalTextPosition(SwingConstants.BOTTOM);
        materias.setHorizontalTextPosition(SwingConstants.CENTER);
        materias.setPreferredSize(new Dimension(200, 100)); // Ajusta el tamaño
        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(materias, gbc);

        // Etiqueta y botón para el primer botón adicional
        JLabel promedios = new JLabel("Mejores Promedios de cada carrera");
        promedios.setForeground(Color.BLACK);
        promedios.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(promedios, gbc);

        JButton promedio = new JButton(new ImageIcon("G:/Mathias/GestiondeNotasEstudiantes/promedio.png"));
        promedio.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica del botón adicional 1
                JOptionPane.showMessageDialog(frame, "Haz clic en Botón Adicional 1");
            }
        });
        promedio.setVerticalTextPosition(SwingConstants.BOTTOM);
        promedio.setHorizontalTextPosition(SwingConstants.CENTER);
        promedio.setPreferredSize(new Dimension(200, 100)); // Ajusta el tamaño
        gbc.gridx = 1;
        gbc.gridy = 2;
        panel.add(promedio, gbc);

        // Etiqueta y botón para el segundo botón adicional
        JLabel reportes = new JLabel("Generar Reporte");
        reportes.setForeground(Color.BLACK);
        reportes.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridx = 1;
        gbc.gridy = 3;
        panel.add(reportes, gbc);

        JButton reporte = new JButton(new ImageIcon("G:/Mathias/GestiondeNotasEstudiantes/reporte.png"));
        reporte.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica del botón adicional 2
                JOptionPane.showMessageDialog(frame, "Haz clic en Botón Adicional 2");
            }
        });
        reporte.setVerticalTextPosition(SwingConstants.BOTTOM);
        reporte.setHorizontalTextPosition(SwingConstants.CENTER);
        reporte.setPreferredSize(new Dimension(200, 100)); // Ajusta el tamaño
        gbc.gridx = 1;
        gbc.gridy = 4;
        panel.add(reporte, gbc);
        
        // Etiqueta y botón para el botón Salir
        JLabel etiquetaSalir = new JLabel("Salir");
        etiquetaSalir.setForeground(Color.BLACK);
        etiquetaSalir.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridx = 1;
        gbc.gridy = 5;
        panel.add(etiquetaSalir, gbc);

        JButton botonSalir = new JButton(new ImageIcon("G:/Mathias/GestiondeNotasEstudiantes/salir.png"));
        botonSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        botonSalir.setVerticalTextPosition(SwingConstants.BOTTOM);
        botonSalir.setHorizontalTextPosition(SwingConstants.CENTER);
        botonSalir.setPreferredSize(new Dimension(200, 100)); // Ajusta el tamaño
        gbc.gridx = 1;
        gbc.gridy = 6;
        panel.add(botonSalir, gbc);

        // Agrega el panel con los botones al fondo
        fondo.add(panel);

        // Agrega el fondo al frame
        frame.setContentPane(fondo);

        // Agrega un ComponentListener para redimensionar la imagen cuando cambie el tamaño del frame
        frame.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                redimensionarImagen();
            }
        });
    }

    private void redimensionarImagen() {
        ImageIcon imagenFondo = new ImageIcon("G:\\Mathias\\GestiondeNotasEstudiantes\\fondo.jpg");
        Image img = imagenFondo.getImage();
        Image imgEscalada = img.getScaledInstance(frame.getWidth(), frame.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon imagenFondoEscalada = new ImageIcon(imgEscalada);

        // Verifica que el componente del contenido sea un JLabel
        if (frame.getContentPane().getComponent(0) instanceof JLabel) {
            JLabel fondo = (JLabel) frame.getContentPane().getComponent(0);
            fondo.setIcon(imagenFondoEscalada);
        }
    }

    public static MenuFormularios obtenerInstancia() {
        if (instancia == null) {
            instancia = new MenuFormularios();
        }
        return instancia;
    }

    public void mostrarVentana() {
        frame.setVisible(true);
    }

    public void ocultarVentana() {
        frame.setVisible(false);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenuFormularios.obtenerInstancia().mostrarVentana();
        });
    }
}