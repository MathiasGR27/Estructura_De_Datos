package gestiondenotasestudiantes;

import java.util.List;
import javax.swing.JOptionPane;


public class Conexion {
    
}
   
