/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arbolbinario_gualpamathias;


public class Nodo {//represneta un nodo dentro del arbol
  public int value;//tiene un valro entero
  //refrencia la hijo izquiedo
  public Nodo left;
    //refrencia la hijo derecho
  public Nodo right;

  public Nodo(int value) {
    this.value = value;
  }
}
