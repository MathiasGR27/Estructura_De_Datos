/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package invertirarbolbinario;

public class InvertirArbolBinario {
    
    public Node invertirAbol(Node root) {
        throw new UnsupportedOperationException("No implementado todavía");
    } 
}
