/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package invertirarbolbinario;

/**
 *
 * @author ESPE
 */
public class ValidateBSTSolution {
    public boolean isValidBST(Node root) {
        return isValidBST(root, null, null);
    }
 
    public boolean isValidBST(Node root, Integer min, Integer max) {
        if (root == null) return true;
        if ((min != null && root.value <= min) || (max != null && root.value >= max)) return false;
        return isValidBST(root.left, min, root.value) && isValidBST(root.right, root.value, max);
    }
}
