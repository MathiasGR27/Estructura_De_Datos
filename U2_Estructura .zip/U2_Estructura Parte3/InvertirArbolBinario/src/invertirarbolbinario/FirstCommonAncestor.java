/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package invertirarbolbinario;

/**
 *
 * @author ESPE
 */
public class FirstCommonAncestor {
    public Node firstCommonAncestor(Node root, Node firstNode, Node secondNode) {
        throw new UnsupportedOperationException("No implementado todavía ");
 }

}
