/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package invertirarbolbinario;

/**
 *
 * @author ESPE
 */
public class MaximumDepthSolution {
   
    public int maxDepth(Node root) {
        if (root == null) return 0;
        int depthLeft = maxDepth(root.left) + 1;
        int depthRight = maxDepth(root.right) + 1;
        return Math.max(depthLeft, depthRight);
    }
}


