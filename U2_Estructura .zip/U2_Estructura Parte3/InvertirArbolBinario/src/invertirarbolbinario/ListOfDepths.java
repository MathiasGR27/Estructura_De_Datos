/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package invertirarbolbinario;

import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author ESPE
 */
public class ListOfDepths {
    public List<LinkedList<Node>> listOfDepths(Node root) {
        throw new UnsupportedOperationException("No implementado todavía");
    }
}
