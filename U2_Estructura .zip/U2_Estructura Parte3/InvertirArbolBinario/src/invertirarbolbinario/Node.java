/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package invertirarbolbinario;


public class Node {//represneta un nodo dentro del arbol
  public int value;//tiene un valro entero
  //refrencia la hijo izquiedo
  public Node left;
    //refrencia la hijo derecho
  public Node right;

  public Node(int value) {
    this.value = value;
  }
}
