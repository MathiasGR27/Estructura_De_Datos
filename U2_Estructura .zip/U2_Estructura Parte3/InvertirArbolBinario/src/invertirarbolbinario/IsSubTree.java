/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package invertirarbolbinario;

/**
 *
 * @author ESPE
 */
public class IsSubTree {
    public boolean isSubtree(Node first, Node second) {
        throw new UnsupportedOperationException("No implementado todavía ");
    }
}

