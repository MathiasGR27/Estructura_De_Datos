/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package invertirarbolbinario;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;


public class Main {
         private Node arbol = null;

    public static void main(String[] args) {
        Main main = new Main();
        main.mostrarMenu();
    }

    // Método principal para mostrar el menú y manejar las opciones del usuario
    public void mostrarMenu() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Crear y mostrar arbol");
            System.out.println("2. Invertir Arbol Binario");
            System.out.println("3. Lista de Profundidades");
            System.out.println("4. Maxima Profundidad");
            System.out.println("5. Validar BST");
            System.out.println("6. Verificar Subarbol");
            System.out.println("7. Salir");

            System.out.print("Seleccione una opcion: ");
            int opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    crearArbolDinamico();
                    break;
                case 2:
                    mostrarArbol(arbol);
                    invertir();
                    System.out.println("Invertir Árbol Binario ");
                    break;
                case 3:
                    listofdepths();
                    break;
                case 4:
                    maximumdepth();
                    break;
                case 5:
                    mostrarArbol(arbol);
                    validatebst();
                    break;
                case 6:
                    mostrarArbol(arbol);
                    issubtree();
                    break;
                case 7:
                    System.out.println("Fin del programa");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Opción no válida");
            }

            // Consume el salto de línea pendiente después de nextInt()
            scanner.nextLine();
        }
    }
    
    
    // Método para insertar un nodo en el árbol
    private void insertarNodoArbol(int numero) {
        Node nodo = new Node(numero);
        if (arbol == null) {
            arbol = nodo;
        } else {
            Node aux = arbol;
            Node prev = aux;
            while (aux != null) {
                prev = aux;
                if (numero < aux.value) {
                    aux = aux.left;
                } else {
                    aux = aux.right;
                }
            }
            if (numero < prev.value) {
                prev.left = nodo;
            } else {
                prev.right = nodo;
            }
        }
    }

    // Método para mostrar el árbol
    private void mostrarArbol(Node arbol) {
        System.out.println("\n\nÁrbol actual:");
        mostrarArbolAux(arbol, 0);
        System.out.println();
    }

    // Método auxiliar para mostrar el árbol con formato
    private void mostrarArbolAux(Node node, int depth) {
        if (node == null) {
            return;
        }

        mostrarArbolAux(node.right, depth + 1);

        for (int i = 0; i < depth; i++) {
            System.out.print("    ");
        }

        System.out.println(node.value);

        mostrarArbolAux(node.left, depth + 1);
    }

    // Método para crear el árbol con nodos ingresados por el usuario
    private void crearArbolDinamico() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el numero de nodos para el árbol: ");
        int numNodos = scanner.nextInt();

        for (int i = 0; i < numNodos; i++) {
            System.out.print("Ingrese el valor del nodo " + (i + 1) + ": ");
            int valor = scanner.nextInt();
            insertarNodoArbol(valor);
        }

        System.out.println("\n\nÁrbol creado exitosamente");
        mostrarArbol(arbol);
    }

    // Método para imprimir el árbol en orden
    private void ordenarArbol(Node nodo) {
        if (nodo != null) {
            ordenarArbol(nodo.left);
            System.out.print(nodo.value + " ");
            ordenarArbol(nodo.right);
        }
    }

    // Método para invertir el árbol
    public void invertir() {
        InvertirArbolBinarioSolucion invertirArbolBinario = new InvertirArbolBinarioSolucion();
        Node newRoot = invertirArbolBinario.invertirAbol(arbol); // Usar el árbol predeterminado
        System.out.println("\nArbol invertido:");
        mostrarArbolAux(newRoot, 0);
    }

    // Método para obtener la lista de profundidades del árbol
    public void listofdepths() {
        ListOfDepthsSolution listOfDepths = new ListOfDepthsSolution();
        List<LinkedList<Node>> result = listOfDepths.listOfDepths(arbol); // Usar el árbol predeterminado
        System.out.println("\nLista de Profundidades:");
        for (int i = 1; i <= result.size(); i++) {
            System.out.print("Nivel " + i + ": ");
            for (Node node : result.get(i - 1)) {
                System.out.print(node.value + " ");
            }
            System.out.println();
        }
    }

    // Método para obtener la máxima profundidad del árbol
    public void maximumdepth() {
        MaximumDepthSolution maxDepth = new MaximumDepthSolution();
        int depth = maxDepth.maxDepth(arbol); // Usar el árbol predeterminado
        System.out.println("\nMaxima Profundidad: " + depth);
    }

    // Método para validar si el árbol es un BST
    public void validatebst() {
        ValidateBSTSolution validateBst = new ValidateBSTSolution();
        boolean isValid = validateBst.isValidBST(arbol); // Usar el árbol predeterminado
        System.out.println("\nEs un BST: " + isValid);
    }

    // Método para verificar si un árbol es subárbol de otro
    public void issubtree() {
        IsSubTreeSolution isSubTree = new IsSubTreeSolution();
        Node second = new Node(5);
        second.left = new Node(1);
        second.right = new Node(3);
        second.left.left = new Node(8);
        boolean isSubtree = isSubTree.isSubtree(arbol, second); // Usar el árbol predeterminado
        System.out.println("\nEs un subarbol: " + isSubtree);
    }
}

