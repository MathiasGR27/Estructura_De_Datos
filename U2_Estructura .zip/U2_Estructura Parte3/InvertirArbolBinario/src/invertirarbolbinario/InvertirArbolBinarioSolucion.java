/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package invertirarbolbinario;


public class InvertirArbolBinarioSolucion {
    public Node invertirAbol(Node root) {
        if (root == null) return null;
        Node tmp = root.left;
        root.left = invertirAbol(root.right);
        root.right = invertirAbol(tmp);
        return root;
    }
}


