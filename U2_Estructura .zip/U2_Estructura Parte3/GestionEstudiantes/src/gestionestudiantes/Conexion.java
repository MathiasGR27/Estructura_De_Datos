package gestionestudiantes;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.MongoException;
import com.mongodb.client.DistinctIterable;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import com.mongodb.connection.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import org.bson.Document;


public class Conexion {
    MongoClient mongo;
    DB basedata;
    DBCollection coolletion;
    MongoCollection<Document> collection;
    String server = "localhost";
    int puerto = 27017;
    
    public MongoClient crearConexion(){
        MongoClient mongoC = null;
        try{
            mongoC = new MongoClient(server, puerto);
            List<String> nombreBaseDatos = mongoC.getDatabaseNames();
            JOptionPane.showMessageDialog(null, "Conexion a Mongo exitosa");
        }catch(MongoException e){
            JOptionPane.showMessageDialog(null, "Error de conexion a la base de datos " + e.toString());
        }
        return mongoC;
    }
    
    public void insertarPeriodo(String periodo, String carrera) {
    MongoClient mongo = crearConexion();
    MongoDatabase database = mongo.getDatabase("periodo");
    MongoCollection<Document> collection = database.getCollection("Periodo");

    Document nuevoPeriodo = new Document();
    nuevoPeriodo.put("periodo", periodo);
    nuevoPeriodo.put("carrera", carrera);

    collection.insertOne(nuevoPeriodo);
    JOptionPane.showMessageDialog(null, "Periodo registrado en la base de datos");
}
    
    public void eliminarPeriodo(String nombrePeriodo) {
    MongoClient mongo = crearConexion();
    try {
        MongoDatabase database = mongo.getDatabase("periodo");
        MongoCollection<Document> collection = database.getCollection("Periodo");

        // Corregir el nombre del campo en la lógica para eliminar el documento
        collection.deleteOne(Filters.eq("periodo", nombrePeriodo));

        JOptionPane.showMessageDialog(null, "Periodo eliminado de la base de datos");
    } catch (MongoException e) {
        JOptionPane.showMessageDialog(null, "Error al eliminar el periodo en la base de datos MongoDB: " + e.toString());
    } finally {
        cerrarConexion();
    }
}

public void actualizarPeriodo(String nombreAntiguo, String nuevoPeriodo, String nuevaCarrera) {
    MongoClient mongo = crearConexion();
    try {
        MongoDatabase database = mongo.getDatabase("periodo");
        MongoCollection<Document> collection = database.getCollection("Periodo");

        // Corregir el nombre del campo en la lógica para actualizar el documento
        collection.updateOne(Filters.eq("periodo", nombreAntiguo), Updates.combine(
                Updates.set("periodo", nuevoPeriodo),
                Updates.set("carrera", nuevaCarrera)
        ));

        JOptionPane.showMessageDialog(null, "Periodo actualizado en la base de datos");
    } catch (MongoException e) {
        JOptionPane.showMessageDialog(null, "Error al actualizar el periodo en la base de datos MongoDB: " + e.toString());
    } finally {
        cerrarConexion();
    }
}
        public void insertarMatricula(matriculas matricula) {
        MongoClient mongo = crearConexion();
        MongoDatabase database = mongo.getDatabase("Matriculacion");
        MongoCollection<Document> collection = database.getCollection("Matricula");

        Document nuevaMatricula = new Document();
        nuevaMatricula.put("nrcMaterias", matricula.getNrcMaterias());
        nuevaMatricula.put("semestre", matricula.getSemestre());
        nuevaMatricula.put("nombreMateria", matricula.getNombreMateria());
        nuevaMatricula.put("nombreIngeniero", matricula.getNombreIngeniero());

        collection.insertOne(nuevaMatricula);
        JOptionPane.showMessageDialog(null, "Matrícula registrada en la base de datos");
    }
        
        public void eliminarMatricula(int nrcMaterias) {
    MongoClient mongo = crearConexion();
    try {
        MongoDatabase database = mongo.getDatabase("Matriculacion");
        MongoCollection<Document> collection = database.getCollection("Matricula");

        // Cambiado a "nrcMaterias" en lugar de "nrcMaterias"
        collection.deleteMany(Filters.eq("nrcMaterias", nrcMaterias));

        JOptionPane.showMessageDialog(null, "Matrícula eliminada de la base de datos");
    } catch (MongoException e) {
        JOptionPane.showMessageDialog(null, "Error al eliminar la matrícula en la base de datos MongoDB: " + e.toString());
    } finally {
        cerrarConexion();
    }
}

    public void actualizarMatricula(int nrcMateriasAntiguo, matriculas nuevaMatricula) {
    MongoClient mongo = crearConexion();
    try {
        MongoDatabase database = mongo.getDatabase("Matriculacion");
        MongoCollection<Document> collection = database.getCollection("Matricula");

        // Cambiado a "nrcMaterias" en lugar de "nrcMaterias"
        collection.updateOne(Filters.eq("nrcMaterias", nrcMateriasAntiguo), Updates.combine(
                Updates.set("nrcMaterias", nuevaMatricula.getNrcMaterias()),
                Updates.set("semestre", nuevaMatricula.getSemestre()),
                Updates.set("nombreMateria", nuevaMatricula.getNombreMateria()),
                Updates.set("nombreIngeniero", nuevaMatricula.getNombreIngeniero())
        ));

        System.out.println("Matrícula actualizada en la base de datos");
    } catch (MongoException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Error al actualizar la matrícula en la base de datos MongoDB: " + e.toString());
    } finally {
        cerrarConexion();
    }
}
    public boolean insertarEstudiante(Estudiantes estudiante) {
    MongoClient mongo = crearConexion();
    try {
        MongoDatabase database = mongo.getDatabase("GestionNotas");
        MongoCollection<Document> collection = database.getCollection("Estudiantes");

        Document nuevoEstudiante = new Document();
        nuevoEstudiante.put("nombre", estudiante.getNombre());
        nuevoEstudiante.put("apellido", estudiante.getApellido());
        nuevoEstudiante.put("carrera", estudiante.getCarrera());
        nuevoEstudiante.put("notaPrimerParcial", estudiante.getNotaPrimerParcial());
        nuevoEstudiante.put("notaSegundoParcial", estudiante.getNotaSegundoParcial());
        nuevoEstudiante.put("notaTercerParcial", estudiante.getNotaTercerParcial());
        nuevoEstudiante.put("asistencia", estudiante.getAsistencia());
        nuevoEstudiante.put("promedio", estudiante.getPromedio());

        collection.insertOne(nuevoEstudiante);
        return true; // Indica éxito
    } catch (MongoException e) {
        JOptionPane.showMessageDialog(null, "Error al insertar el estudiante en la base de datos MongoDB: " + e.toString(), "Error", JOptionPane.ERROR_MESSAGE);
        return false; // Indica error
    } finally {
        cerrarConexion();
    }
}
    public void eliminarEstudiante(String nombreEstudiante) {
    MongoClient mongo = crearConexion();
    try {
        MongoDatabase database = mongo.getDatabase("GestionNotas");
        MongoCollection<Document> collection = database.getCollection("Estudiantes");

        // Agregar la lógica para eliminar el documento con el nombreEstudiante proporcionado
        collection.deleteOne(Filters.eq("nombre", nombreEstudiante));

        JOptionPane.showMessageDialog(null, "Estudiante eliminado de la base de datos");
    } catch (MongoException e) {
        JOptionPane.showMessageDialog(null, "Error al eliminar el estudiante en la base de datos MongoDB: " + e.toString());
    } finally {
        cerrarConexion();
    }
}
    public void actualizarEstudiante(String nombreAntiguo, String nuevoNombre, String nuevoApellido,String nuevoCarrera,
        double nuevaNotaPrimerParcial, double nuevaNotaSegundoParcial, double nuevaNotaTercerParcial, String nuevaAsistencia) {
    MongoClient mongo = crearConexion();
    try {
        MongoDatabase database = mongo.getDatabase("GestionNotas");
        MongoCollection<Document> collection = database.getCollection("Estudiantes");

        // Agregar la lógica para actualizar el documento con el nombreAntiguo proporcionado
        // En este ejemplo, se asume que tu colección tiene campos "nombre" y otros campos relevantes
        collection.updateOne(Filters.eq("nombre", nombreAntiguo), Updates.combine(
                Updates.set("nombre", nuevoNombre),
                Updates.set("apellido", nuevoApellido),
                Updates.set("carreca", nuevoCarrera),
                Updates.set("notaPrimerParcial", nuevaNotaPrimerParcial),
                Updates.set("notaSegundoParcial", nuevaNotaSegundoParcial),
                Updates.set("notaTercerParcial", nuevaNotaTercerParcial),
                Updates.set("asistencia", nuevaAsistencia)
        ));

        JOptionPane.showMessageDialog(null, "Estudiante actualizado en la base de datos");
    } catch (MongoException e) {
        JOptionPane.showMessageDialog(null, "Error al actualizar el estudiante en la base de datos MongoDB: " + e.toString());
    } finally {
        cerrarConexion();
    }
}
      // Método para actualizar la base de datos con la lista de estudiantes actualizada
    public void actualizarBaseDeDatos(List<Estudiantes> listaEstudiantes) {
        MongoClient mongo = crearConexion();

        try {
            MongoDatabase database = mongo.getDatabase("GestionNotas");
            MongoCollection<Document> collection = database.getCollection("Estudiantes");

            // Elimina todos los documentos existentes en la colección
            collection.deleteMany(new Document());

            // Inserta los estudiantes actualizados en la base de datos
            for (Estudiantes estudiante : listaEstudiantes) {
                Document nuevoEstudiante = new Document();
                nuevoEstudiante.put("nombre", estudiante.getNombre());
                nuevoEstudiante.put("apellido", estudiante.getApellido());
                nuevoEstudiante.put("carrera", estudiante.getCarrera());
                nuevoEstudiante.put("notaPrimerParcial", estudiante.getNotaPrimerParcial());
                nuevoEstudiante.put("notaSegundoParcial", estudiante.getNotaSegundoParcial());
                nuevoEstudiante.put("notaTercerParcial", estudiante.getNotaTercerParcial());
                nuevoEstudiante.put("asistencia", estudiante.getAsistencia());
                nuevoEstudiante.put("promedio", estudiante.getPromedio());

                collection.insertOne(nuevoEstudiante);
            }

            JOptionPane.showMessageDialog(null, "Base de datos actualizada con la lista ordenada de estudiantes");
        } catch (MongoException e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar la base de datos MongoDB: " + e.toString());
        } finally {
            cerrarConexion();
        }
    }
    
   public List<Estudiantes> obtenerTresMejoresPromedios(String carrera) {
    mongo = crearConexion();
    MongoDatabase database = mongo.getDatabase("GestionNotas");
    MongoCollection<Document> collection = database.getCollection("Estudiantes");

    // Filtra por carrera y ordena por promedio en orden descendente
    FindIterable<Document> documentos = collection.find(new Document("carrera", carrera))
            .sort(new Document("promedio", -1))
            .limit(3);

    List<Estudiantes> mejoresPromedios = new ArrayList<>();

    for (Document documento : documentos) {
        Estudiantes estudiante = new Estudiantes();
        estudiante.setNombre(documento.getString("nombre"));
        estudiante.setApellido(documento.getString("apellido"));
        estudiante.setCarrera(documento.getString("carrera"));
        estudiante.setAsistencia(documento.getString("asistencia"));
        estudiante.setNotaPrimerParcial(documento.getDouble("notaPrimerParcial"));
        estudiante.setNotaSegundoParcial(documento.getDouble("notaSegundoParcial"));
        estudiante.setNotaTercerParcial(documento.getDouble("notaTercerParcial"));
        estudiante.setPromedio(documento.getDouble("promedio"));
        mejoresPromedios.add(estudiante);
    }

    return mejoresPromedios;
}
   
   
    public List<Estudiantes> obtenerMejoresPromedios(String carrera) {
    mongo = crearConexion();
    MongoDatabase database = mongo.getDatabase("GestionNotas");
    MongoCollection<Document> collection = database.getCollection("Estudiantes");

    // Filtra por carrera y ordena por promedio en orden descendente
    FindIterable<Document> documentos = collection.find(new Document("carrera", carrera))
            .sort(new Document("promedio", -1))
            .limit(3);

    List<Estudiantes> mejoresPromedios = new ArrayList<>();

    for (Document documento : documentos) {
        Estudiantes estudiante = new Estudiantes();
        estudiante.setNombre(documento.getString("nombre"));
        estudiante.setApellido(documento.getString("apellido"));
        estudiante.setCarrera(documento.getString("carrera"));
        estudiante.setAsistencia(documento.getString("asistencia"));
        estudiante.setNotaPrimerParcial(documento.getDouble("notaPrimerParcial"));
        estudiante.setNotaSegundoParcial(documento.getDouble("notaSegundoParcial"));
        estudiante.setNotaTercerParcial(documento.getDouble("notaTercerParcial"));
        estudiante.setPromedio(documento.getDouble("promedio"));
        mejoresPromedios.add(estudiante);
    }

    return mejoresPromedios;
}
    
    public List<Estudiantes> obtenerTodosEstudiantes() {
        List<Estudiantes> todosEstudiantes = new ArrayList<>();

        try {
            mongo = crearConexion();
            MongoDatabase database = mongo.getDatabase("GestionNotas");
            MongoCollection<Document> collection = database.getCollection("Estudiantes");

            FindIterable<Document> documentos = collection.find();

            for (Document documento : documentos) {
                Estudiantes estudiante = new Estudiantes();
                estudiante.setNombre(documento.getString("nombre"));
                estudiante.setApellido(documento.getString("apellido"));
                estudiante.setCarrera(documento.getString("carrera"));
                estudiante.setAsistencia(documento.getString("asistencia"));
                estudiante.setNotaPrimerParcial(documento.getDouble("notaPrimerParcial"));
                estudiante.setNotaSegundoParcial(documento.getDouble("notaSegundoParcial"));
                estudiante.setNotaTercerParcial(documento.getDouble("notaTercerParcial"));
                estudiante.setPromedio(documento.getDouble("promedio"));
                todosEstudiantes.add(estudiante);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            cerrarConexion();
        }

        return todosEstudiantes;
    }

    
   public List<String> obtenerCarrerasDisponibles() {
        List<String> carreras = new ArrayList<>();

        try {
            mongo = crearConexion();
            MongoDatabase database = mongo.getDatabase("GestionNotas");
            MongoCollection<Document> collection = database.getCollection("Estudiantes");

            // Obtener carreras disponibles utilizando Distinct
            DistinctIterable<String> distinctCarreras = collection.distinct("carrera", String.class);

            for (String carrera : distinctCarreras) {
                carreras.add(carrera);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarConexion();
        }

        return carreras;
    }
   
    public void cerrarConexion() {
        if (mongo != null) {
            mongo.close();
            JOptionPane.showMessageDialog(null, "Conexión cerrada");
        }
    }
}

   
