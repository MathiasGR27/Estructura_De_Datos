package gestionestudiantes;

import com.mongodb.connection.Connection;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class GestiondeNotasEstudiantes extends JFrame {

     private JTextField nombreTextField;
    private JTextField apellidoTextField;
    private JTextField notaPrimerParcialTextField;
    private JTextField notaSegundoParcialTextField;
    private JTextField notaTercerParcialTextField;
    private JTextField carreraTextField;
    private JComboBox<String> asistenciaComboBox;
    private JComboBox<String> metodoOrdenamientoComboBox;
    
    private JTable tablaEstudiantes;
    private DefaultTableModel modeloTabla;

    private List<Estudiantes> listaEstudiantes = new ArrayList<>();

    public GestiondeNotasEstudiantes() {
        // Configuración de la ventana principal
        setTitle("Gestión de Notas de Estudiantes");
        setSize(900, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Crear componentes del formulario
        nombreTextField = new JTextField(20);
        apellidoTextField = new JTextField(20);
        carreraTextField = new JTextField(20);
        notaPrimerParcialTextField = new JTextField(5);
        notaSegundoParcialTextField = new JTextField(5);
        notaTercerParcialTextField = new JTextField(5);

        String[] asistencia = {"Presente", "No Presente"};
        asistenciaComboBox = new JComboBox<>(asistencia);

        String[] opcionesOrdenamiento = {"Burbuja", "Quicksort", "Merge Sort"};
        metodoOrdenamientoComboBox = new JComboBox<>(opcionesOrdenamiento);

        JButton guardarButton = new JButton("Guardar");
        JButton ordenarNotasButton = new JButton("Ordenar Notas");
        JButton eliminarButton = new JButton("Eliminar");
        JButton actualizarButton = new JButton("Actualizar");
        JButton busquedaSecuencialButton = new JButton("Búsqueda Secuencial");
        JButton busquedaBinariaButton = new JButton("Búsqueda Binaria");
        JButton salirButton = new JButton("Salir");

        // Configurar la tabla
        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("Nombre");
        modeloTabla.addColumn("Apellido");
        modeloTabla.addColumn("Carrera");
        modeloTabla.addColumn("Nota Primer Parcial");
        modeloTabla.addColumn("Nota Segundo Parcial");
        modeloTabla.addColumn("Nota Tercer Parcial");
        modeloTabla.addColumn("Asistencia");
        modeloTabla.addColumn("Promedio");

        tablaEstudiantes = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tablaEstudiantes);

        // Configurar el diseño del formulario
        JPanel panelPrincipal = new JPanel(new GridLayout(1, 3, 10, 0)); // GridLayout con 1 fila y 3 columnas
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Espacio alrededor del panel

        // Columna 1
        JPanel columna1 = new JPanel(new GridLayout(8, 4, 9, 10)); // GridLayout con 8 filas y 1 columna
        columna1.add(new JLabel("Nombre:"));
        columna1.add(new JLabel("Apellido:"));
        columna1.add(new JLabel("Carrera:"));
        columna1.add(new JLabel("Nota Parcial 1 :"));
        columna1.add(new JLabel("Nota Parcial 2:"));
        columna1.add(new JLabel("Nota Parcial 3:"));
        columna1.add(new JLabel("Asistencia:"));
        columna1.add(new JLabel("Método de Ordenamiento:"));

        // Columna 2
        JPanel columna2 = new JPanel(new GridLayout(8, 4, 9, 10)); // GridLayout con 8 filas y 1 columna
        columna2.add(nombreTextField);
        columna2.add(apellidoTextField);
        columna2.add(carreraTextField);
        columna2.add(notaPrimerParcialTextField);
        columna2.add(notaSegundoParcialTextField);
        columna2.add(notaTercerParcialTextField);
        columna2.add(asistenciaComboBox);
        columna2.add(metodoOrdenamientoComboBox);

        // Columna 3
        JPanel columna3 = new JPanel(new GridLayout(4, 4, 9, 10)); // GridLayout con 4 filas y 1 columna
        columna3.add(guardarButton);
        columna3.add(ordenarNotasButton);
        columna3.add(eliminarButton);
        columna3.add(actualizarButton);
        columna3.add(busquedaSecuencialButton);
        columna3.add(busquedaBinariaButton);
        columna3.add(salirButton);

        // Agregar componentes al panel principal
        panelPrincipal.add(columna1);
        panelPrincipal.add(columna2);
        panelPrincipal.add(columna3);

        // Configurar el color de la tabla
        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
        headerRenderer.setBackground(new Color(173, 216, 230)); // Celeste
        for (int i = 0; i < tablaEstudiantes.getModel().getColumnCount(); i++) {
            tablaEstudiantes.getColumnModel().getColumn(i).setHeaderRenderer(headerRenderer);
        }

        // Configurar el color inicial y de resaltado para los botones
        Color colorInicial = new Color(173, 216, 230); // Celeste
        Color colorResaltado = new Color(0, 255, 255); // Azul

        // Agregar el panel de menú al contenedor principal
        add(panelPrincipal, BorderLayout.CENTER);
        add(scrollPane, BorderLayout.SOUTH);
    
    

        guardarButton.addActionListener(new ActionListener() {
            @Override
         public void actionPerformed(ActionEvent e) {
        // Obtener los valores de los campos o de donde corresponda
        String nombre = nombreTextField.getText().trim();
        String apellido = apellidoTextField.getText().trim();
        String carrera = carreraTextField.getText().trim();
        String asistencia = asistenciaComboBox.getSelectedItem().toString();
        double notaPrimerParcial;
        double notaSegundoParcial;
        double notaTercerParcial;
        
        // Validar que nombre y apellido solo contengan caracteres
        if (!nombre.matches("[a-zA-Z]+") || !apellido.matches("[a-zA-Z]+")) {
            JOptionPane.showMessageDialog(null, "El nombre, apellido y carrera deben contener solo caracteres.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // Validar que las notas parciales sean números en el rango de 0 a 20
            notaPrimerParcial = Double.parseDouble(notaPrimerParcialTextField.getText().trim());
            notaSegundoParcial = Double.parseDouble(notaSegundoParcialTextField.getText().trim());
            notaTercerParcial = Double.parseDouble(notaTercerParcialTextField.getText().trim());

            if (notaPrimerParcial < 0 || notaPrimerParcial > 20 ||
                notaSegundoParcial < 0 || notaSegundoParcial > 20 ||
                notaTercerParcial < 0 || notaTercerParcial > 20) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Las notas parciales deben ser números en el rango de 0 a 20.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double promedio = calcularPromedio(notaPrimerParcial, notaSegundoParcial, notaTercerParcial);

        // Crear el estudiante aquí o donde sea apropiado en tu lógica
        Estudiantes estudiante = new Estudiantes(nombre, apellido,carrera, asistencia, notaPrimerParcial, notaSegundoParcial, notaTercerParcial, promedio);

        // Luego, agregar el estudiante y guardar en la base de datos
        agregarEstudiante();
        Conexion conexion = new Conexion();
        conexion.insertarEstudiante(estudiante);
        
    }
});

       eliminarButton.addActionListener(new ActionListener() {
       @Override
        public void actionPerformed(ActionEvent e) {
        // Obtener el índice seleccionado en la tabla
        int indiceSeleccionado = tablaEstudiantes.getSelectedRow();

        // Verificar si se ha seleccionado una fila
        if (indiceSeleccionado != -1) {
            // Obtener el nombre del estudiante seleccionado en la tabla
            String nombreEstudiante = (String) modeloTabla.getValueAt(indiceSeleccionado, 0);

            // Eliminar el estudiante de la base de datos y de la interfaz gráfica
            Conexion conexion = new Conexion();
            conexion.eliminarEstudiante(nombreEstudiante);
            
            // Eliminar la fila seleccionada de la tabla y de la lista
            modeloTabla.removeRow(indiceSeleccionado);
            listaEstudiantes.remove(indiceSeleccionado);

            JOptionPane.showMessageDialog(null, "Estudiante eliminado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione un estudiante para eliminar.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }
});


        actualizarButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        // Obtener el índice seleccionado en la tabla
        int indiceSeleccionado = tablaEstudiantes.getSelectedRow();

        // Verificar si se ha seleccionado una fila
        if (indiceSeleccionado != -1) {
            // Obtener los nuevos valores de los campos
            String nuevoNombre = nombreTextField.getText().trim();
            String nuevoApellido = apellidoTextField.getText().trim();
            String nuevoCarrera = carreraTextField.getText().trim();

            // Validar que nombre y apellido solo contengan caracteres
            if (!nuevoNombre.matches("[a-zA-Z]+") || !nuevoApellido.matches("[a-zA-Z]+")) {
                JOptionPane.showMessageDialog(null, "El nombre, apellido y carrera deben contener solo caracteres.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            double nuevaNotaPrimerParcial;
            double nuevaNotaSegundoParcial;
            double nuevaNotaTercerParcial;

            try {
                // Obtener las nuevas notas y validar que estén en el rango de 0 a 20
                nuevaNotaPrimerParcial = Double.parseDouble(notaPrimerParcialTextField.getText().trim());
                nuevaNotaSegundoParcial = Double.parseDouble(notaSegundoParcialTextField.getText().trim());
                nuevaNotaTercerParcial = Double.parseDouble(notaTercerParcialTextField.getText().trim());

                if (nuevaNotaPrimerParcial < 0 || nuevaNotaPrimerParcial > 20 ||
                    nuevaNotaSegundoParcial < 0 || nuevaNotaSegundoParcial > 20 ||
                    nuevaNotaTercerParcial < 0 || nuevaNotaTercerParcial > 20) {
                    throw new NumberFormatException();
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Las notas parciales deben ser números en el rango de 0 a 20.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String nuevaAsistencia = (String) asistenciaComboBox.getSelectedItem();

            // Calcular el nuevo promedio
            double nuevoPromedio = (nuevaNotaPrimerParcial + nuevaNotaSegundoParcial + nuevaNotaTercerParcial) / 3;

            // Actualizar el estudiante en la base de datos y en la interfaz gráfica
            Conexion conexion = new Conexion();
            conexion.actualizarEstudiante(
                (String) modeloTabla.getValueAt(indiceSeleccionado, 0), // Nombre antiguo
                nuevoNombre, nuevoApellido,nuevoCarrera, nuevaNotaPrimerParcial,
                nuevaNotaSegundoParcial, nuevaNotaTercerParcial, nuevaAsistencia
            );
            
            // Actualizar la fila seleccionada en la tabla y en la lista
            modeloTabla.setValueAt(nuevoNombre, indiceSeleccionado, 0);
            modeloTabla.setValueAt(nuevoApellido, indiceSeleccionado, 1);
            modeloTabla.setValueAt(nuevoCarrera, indiceSeleccionado, 2);
            modeloTabla.setValueAt(nuevaNotaPrimerParcial, indiceSeleccionado, 3);
            modeloTabla.setValueAt(nuevaNotaSegundoParcial, indiceSeleccionado, 4);
            modeloTabla.setValueAt(nuevaNotaTercerParcial, indiceSeleccionado, 5);
            modeloTabla.setValueAt(nuevaAsistencia, indiceSeleccionado, 5);
            modeloTabla.setValueAt(nuevoPromedio, indiceSeleccionado, 6);

            listaEstudiantes.get(indiceSeleccionado).setNombre(nuevoNombre);
            listaEstudiantes.get(indiceSeleccionado).setApellido(nuevoApellido);
            listaEstudiantes.get(indiceSeleccionado).setApellido(nuevoCarrera);
            listaEstudiantes.get(indiceSeleccionado).setNotaPrimerParcial(nuevaNotaPrimerParcial);
            listaEstudiantes.get(indiceSeleccionado).setNotaSegundoParcial(nuevaNotaSegundoParcial);
            listaEstudiantes.get(indiceSeleccionado).setNotaTercerParcial(nuevaNotaTercerParcial);
            listaEstudiantes.get(indiceSeleccionado).setAsistencia(nuevaAsistencia);
            listaEstudiantes.get(indiceSeleccionado).setPromedio(nuevoPromedio);

            JOptionPane.showMessageDialog(null, "Estudiante actualizado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione un estudiante para actualizar.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }
});

        ordenarNotasButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ordenarNotas();
            }
        });
        
        // Luego, configura sus eventos
        busquedaSecuencialButton.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {
                buscarEstudianteSecuencial();
            }     
        });

       busquedaBinariaButton.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {
                buscarEstudianteBinaria();
            }
        });

        salirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Cerrar la ventana actual (la de Periodo)
                GestionEstudiantes1.obtenerInstancia().mostrarVentana(); // Mostrar la ventana de MenuFormularios
            }
        });


        // Configura el color inicial para los botones
        guardarButton.setBackground(colorInicial);
        ordenarNotasButton.setBackground(colorInicial);
        eliminarButton.setBackground(colorInicial);
        actualizarButton.setBackground(colorInicial);
        salirButton.setBackground(colorInicial);
        busquedaSecuencialButton.setBackground(colorInicial);
        busquedaBinariaButton.setBackground(colorInicial);

        // Configurar eventos para cambiar el color al pasar el mouse
        MouseAdapter colorChangeAdapter = new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ((JButton) evt.getSource()).setBackground(colorResaltado);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                ((JButton) evt.getSource()).setBackground(colorInicial);
            }
        };

        // Agregar el adaptador de cambio de color a los botones
        guardarButton.addMouseListener(colorChangeAdapter);
        ordenarNotasButton.addMouseListener(colorChangeAdapter);
        eliminarButton.addMouseListener(colorChangeAdapter);
        actualizarButton.addMouseListener(colorChangeAdapter);
        salirButton.addMouseListener(colorChangeAdapter);
        busquedaSecuencialButton.addMouseListener(colorChangeAdapter);
        busquedaBinariaButton.addMouseListener(colorChangeAdapter);
    }
    
    // Agregar este método para calcular el promedio
private double calcularPromedio(double notaPrimerParcial, double notaSegundoParcial, double notaTercerParcial) {
    return (notaPrimerParcial + notaSegundoParcial + notaTercerParcial) / 3;
}
    
    private void agregarEstudiante() {
    // Obtener los valores de los campos
    String nombre = nombreTextField.getText().trim();
    String apellido = apellidoTextField.getText().trim();
    String carrera = carreraTextField.getText().trim();
    double notaPrimerParcial = Double.parseDouble(notaPrimerParcialTextField.getText().trim());
    double notaSegundoParcial = Double.parseDouble(notaSegundoParcialTextField.getText().trim());
    double notaTercerParcial = Double.parseDouble(notaTercerParcialTextField.getText().trim());
    String asistencia = asistenciaComboBox.getSelectedItem().toString();

    // Calcular el promedio
    double promedio = (notaPrimerParcial + notaSegundoParcial + notaTercerParcial) / 3;

    // Formatear el promedio con dos decimales
    String promedioFormateado = String.format("%.2f", promedio);

    // Crear una instancia de Estudiantes y establecer los valores, incluido el promedio calculado
    Estudiantes estudiante = new Estudiantes(nombre, apellido,carrera, asistencia, notaPrimerParcial, notaSegundoParcial, notaTercerParcial, promedio);

    // Agregar información a la lista y a la tabla
    listaEstudiantes.add(estudiante);
    Object[] fila = {nombre, apellido,carrera, notaPrimerParcial, notaSegundoParcial, notaTercerParcial, asistencia, promedioFormateado};
    modeloTabla.addRow(fila);

    // Limpiar los campos después de la inserción (opcional)
    nombreTextField.setText("");
    apellidoTextField.setText("");
    carreraTextField.setText("");
    notaPrimerParcialTextField.setText("");
    notaSegundoParcialTextField.setText("");
    notaTercerParcialTextField.setText("");
    asistenciaComboBox.setSelectedIndex(0);
}

    private void eliminarEstudiante() {
        int indiceSeleccionado = tablaEstudiantes.getSelectedRow();
        if (indiceSeleccionado != -1) {
            // Eliminar la fila seleccionada de la tabla y de la lista
            modeloTabla.removeRow(indiceSeleccionado);
            listaEstudiantes.remove(indiceSeleccionado);
            JOptionPane.showMessageDialog(null, "Eliminado exitosamente localmente.", "Aviso", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione un estudiante para eliminar.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void actualizarEstudiante() {
        int indiceSeleccionado = tablaEstudiantes.getSelectedRow();
        if (indiceSeleccionado != -1) {
            // Obtener los nuevos valores de los campos
            String nuevoNombre = nombreTextField.getText().trim();
            String nuevoApellido = apellidoTextField.getText().trim();
            String nuevocarrera = carreraTextField.getText().trim();
            double nuevaNotaPrimerParcial = Double.parseDouble(notaPrimerParcialTextField.getText().trim());
            double nuevaNotaSegundoParcial = Double.parseDouble(notaSegundoParcialTextField.getText().trim());
            double nuevaNotaTercerParcial = Double.parseDouble(notaTercerParcialTextField.getText().trim());
            String nuevaAsistencia = (String) asistenciaComboBox.getSelectedItem();

            // Calcular el nuevo promedio
            double nuevoPromedio = (nuevaNotaPrimerParcial + nuevaNotaSegundoParcial + nuevaNotaTercerParcial) / 3;

            // Actualizar la fila seleccionada en la tabla y en la lista
            modeloTabla.setValueAt(nuevoNombre, indiceSeleccionado, 0);
            modeloTabla.setValueAt(nuevoApellido, indiceSeleccionado, 1);
            modeloTabla.setValueAt(nuevocarrera, indiceSeleccionado, 2);
            modeloTabla.setValueAt(nuevaNotaPrimerParcial, indiceSeleccionado, 3);
            modeloTabla.setValueAt(nuevaNotaSegundoParcial, indiceSeleccionado, 4);
            modeloTabla.setValueAt(nuevaNotaTercerParcial, indiceSeleccionado, 5);
            modeloTabla.setValueAt(nuevaAsistencia, indiceSeleccionado, 5);
            modeloTabla.setValueAt(nuevoPromedio, indiceSeleccionado, 6);

            listaEstudiantes.get(indiceSeleccionado).setNombre(nuevoNombre);
            listaEstudiantes.get(indiceSeleccionado).setApellido(nuevoApellido);
            listaEstudiantes.get(indiceSeleccionado).setApellido(nuevocarrera);
            listaEstudiantes.get(indiceSeleccionado).setNotaPrimerParcial(nuevaNotaPrimerParcial);
            listaEstudiantes.get(indiceSeleccionado).setNotaSegundoParcial(nuevaNotaSegundoParcial);
            listaEstudiantes.get(indiceSeleccionado).setNotaTercerParcial(nuevaNotaTercerParcial);
            listaEstudiantes.get(indiceSeleccionado).setAsistencia(nuevaAsistencia);
            listaEstudiantes.get(indiceSeleccionado).setPromedio(nuevoPromedio);

            JOptionPane.showMessageDialog(null, "Actualizado exitosamente localmente.", "Exito", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione un estudiante para actualizar.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

  private void calcularPromedioEstudiante() {
    int indiceSeleccionado = tablaEstudiantes.getSelectedRow();
    if (indiceSeleccionado != -1) {
        Estudiantes estudianteSeleccionado = listaEstudiantes.get(indiceSeleccionado);

        // Formatear el promedio con dos decimales
        String promedioFormateado = String.format("%.2f", estudianteSeleccionado.getPromedio());

        JOptionPane.showMessageDialog(
                GestiondeNotasEstudiantes.this,
                "Promedio del estudiante " + estudianteSeleccionado.getNombre() + " " + estudianteSeleccionado.getApellido() +
                        ": " + promedioFormateado,
                "Promedio",
                JOptionPane.INFORMATION_MESSAGE
        );
    } else {
        JOptionPane.showMessageDialog(
                GestiondeNotasEstudiantes.this,
                "Seleccione un estudiante de la lista para calcular el promedio.",
                "Aviso",
                JOptionPane.WARNING_MESSAGE
        );
    }
}

    private void ordenarNotas() {
    String metodoSeleccionado = (String) metodoOrdenamientoComboBox.getSelectedItem();

    // Calcular promedios y asociarlos con los elementos
    calcularPromedios(listaEstudiantes);

    // Ordenar la lista según el método seleccionado
    switch (metodoSeleccionado) {
        case "Burbuja":
            ordenarBurbujaConAnimacion(listaEstudiantes);
            break;
        case "Quicksort":
            ordenarQuicksortConAnimacion(listaEstudiantes, 0, listaEstudiantes.size() - 1);
            break;
        case "Merge Sort":
            ordenarMergeSortConAnimacion(listaEstudiantes, 0, listaEstudiantes.size() - 1);
            break;
        default:
            JOptionPane.showMessageDialog(this, "Método de ordenamiento no válido", "Error", JOptionPane.ERROR_MESSAGE);
    }

    // Después de ordenar, actualiza la tabla
    actualizarTabla();
}
    
    private List<Estudiantes> calcularPromedios(List<Estudiantes> elementos) {
        List<Estudiantes> elementosConPromedios = new ArrayList<>();

        for (Estudiantes estudiante : elementos) {
            // No es necesario calcular el promedio aquí, ya que lo obtendremos directamente
            elementosConPromedios.add(estudiante);
        }

        return elementosConPromedios;
    }

private void ordenarBurbujaConAnimacion(List<Estudiantes> lista) {
    OrdenamientoBurbujaWorker worker = new OrdenamientoBurbujaWorker(lista);
    worker.execute();
}

private void ordenarQuicksortConAnimacion(List<Estudiantes> lista, int izquierda, int derecha) {
    QuicksortWorker worker = new QuicksortWorker(lista, izquierda, derecha);
    worker.execute();
}

private void ordenarMergeSortConAnimacion(List<Estudiantes> lista, int izquierda, int derecha) {
    MergeSortWorker worker = new MergeSortWorker(lista, izquierda, derecha);
    worker.execute();
}

private class OrdenamientoBurbujaWorker extends SwingWorker<Void, Void> {
        private List<Estudiantes> lista;

        public OrdenamientoBurbujaWorker(List<Estudiantes> lista) {
            this.lista = lista;
        }

        @Override
        protected Void doInBackground() throws Exception {
            ordenarBurbuja(listaEstudiantes);
            return null;
        }

        @Override
        protected void done() {
            actualizarTabla();
            Conexion conexion = new Conexion();
            conexion.actualizarBaseDeDatos(listaEstudiantes);
            JOptionPane.showMessageDialog(GestiondeNotasEstudiantes.this, "Lista ordenada mediante Burbuja");
        }

        private void ordenarBurbuja(List<Estudiantes> lista) throws InterruptedException {
            int n = lista.size();
            boolean intercambio;
            do {
                intercambio = false;
                for (int i = 0; i < n - 1; i++) {
                    if (lista.get(i).getPromedio() > lista.get(i + 1).getPromedio()) {
                        Collections.swap(lista, i, i + 1);
                        publish();
                        TimeUnit.MILLISECONDS.sleep(500);
                        intercambio = true;
                    }
                }
                n--;
            } while (intercambio);
        }
    }

    private class QuicksortWorker extends SwingWorker<Void, Void> {
        private List<Estudiantes> lista;
        private int izquierda;
        private int derecha;

        public QuicksortWorker(List<Estudiantes> lista, int izquierda, int derecha) {
            this.lista = lista;
            this.izquierda = izquierda;
            this.derecha = derecha;
        }

        @Override
        protected Void doInBackground() throws Exception {
            ordenarQuicksort(listaEstudiantes, izquierda, derecha);
            return null;
        }

        @Override
        protected void done() {
            actualizarTabla();
            Conexion conexion = new Conexion();
            conexion.actualizarBaseDeDatos(listaEstudiantes);
            JOptionPane.showMessageDialog(GestiondeNotasEstudiantes.this, "Lista ordenada mediante Quicksort");
        }

        private void ordenarQuicksort(List<Estudiantes> lista, int izquierda, int derecha) {
            if (izquierda < derecha) {
                int indiceParticion = particion(lista, izquierda, derecha);
                ordenarQuicksort(lista, izquierda, indiceParticion - 1);
                ordenarQuicksort(lista, indiceParticion + 1, derecha);
            }
        }

        private int particion(List<Estudiantes> lista, int izquierda, int derecha) {
            double pivote = lista.get(derecha).getPromedio();
            int i = izquierda - 1;

            for (int j = izquierda; j < derecha; j++) {
                if (lista.get(j).getPromedio() <= pivote) {
                    i++;
                    Collections.swap(lista, i, j);
                }
            }

            Collections.swap(lista, i + 1, derecha);
            return i + 1;
        }
    }

    private class MergeSortWorker extends SwingWorker<Void, Void> {
        private List<Estudiantes> lista;
        private int izquierda;
        private int derecha;

        public MergeSortWorker(List<Estudiantes> lista, int izquierda, int derecha) {
            this.lista = lista;
            this.izquierda = izquierda;
            this.derecha = derecha;
        }

        @Override
        protected Void doInBackground() throws Exception {
            sortMerge(listaEstudiantes, izquierda, derecha);
            return null;
        }

        @Override
        protected void done() {
            actualizarTabla();
            Conexion conexion = new Conexion();
            conexion.actualizarBaseDeDatos(listaEstudiantes);
            JOptionPane.showMessageDialog(GestiondeNotasEstudiantes.this, "Lista ordenada mediante Merge Sort");
        }

        private void sortMerge(List<Estudiantes> lista, int left, int right) {
            if (left < right) {
                int middle = (left + right) / 2;
                sortMerge(lista, left, middle);
                sortMerge(lista, middle + 1, right);
                merge(lista, left, middle, right);
            }
        }

        private void merge(List<Estudiantes> lista, int left, int middle, int right) {
            int n1 = middle - left + 1;
            int n2 = right - middle;
            List<Estudiantes> leftArray = new ArrayList<>(lista.subList(left, left + n1));
            List<Estudiantes> rightArray = new ArrayList<>(lista.subList(middle + 1, middle + 1 + n2));

            int i = 0, j = 0;
            int k = left;

            while (i < n1 && j < n2) {
                if (leftArray.get(i).getPromedio() <= rightArray.get(j).getPromedio()) {
                    lista.set(k, leftArray.get(i));
                    i++;
                } else {
                    lista.set(k, rightArray.get(j));
                    j++;
                }
                k++;
            }

            while (i < n1) {
                lista.set(k, leftArray.get(i));
                i++;
                k++;
            }

            while (j < n2) {
                lista.set(k, rightArray.get(j));
                j++;
                k++;
            }
        }
    }
private void actualizarTabla() {
    // Limpiar el modelo de la tabla
    modeloTabla.setRowCount(0);

    // Llenar la tabla con los datos actualizados
    for (Estudiantes estudiante : listaEstudiantes) {
        // Formatear el promedio con dos decimales antes de agregarlo a la tabla
        String promedioFormateado = String.format("%.2f", estudiante.getPromedio());

        Object[] fila = {
            estudiante.getNombre(),
            estudiante.getApellido(),
            estudiante.getCarrera(),
            estudiante.getNotaPrimerParcial(),
            estudiante.getNotaSegundoParcial(),
            estudiante.getNotaTercerParcial(),
            estudiante.getAsistencia(),
            promedioFormateado  // Agregar el promedio formateado
        };
        modeloTabla.addRow(fila);
    }

    // Imprime los promedios después de ordenar
    System.out.println("Promedios después de ordenar: " + obtenerPromedios(listaEstudiantes));
    
    // Actualiza la base de datos después de ordenar
    Conexion conexion = new Conexion();
    conexion.actualizarBaseDeDatos(listaEstudiantes);
}



private List<Double> obtenerPromedios(List<Estudiantes> estudiantes) {
    List<Double> promedios = new ArrayList<>();
    for (Estudiantes estudiante : estudiantes) {
        promedios.add(estudiante.getPromedio());
    }
    return promedios;
}
private void buscarEstudianteSecuencial() {
    String nombreBusqueda = JOptionPane.showInputDialog("Ingrese el nombre del estudiante:");
    String apellidoBusqueda = JOptionPane.showInputDialog("Ingrese el apellido del estudiante:");

    for (int i = 0; i < listaEstudiantes.size(); i++) {
        Estudiantes estudiante = listaEstudiantes.get(i);
        if (estudiante.getNombre().equalsIgnoreCase(nombreBusqueda) &&
                estudiante.getApellido().equalsIgnoreCase(apellidoBusqueda)) {
            mostrarInformacionEstudiante(estudiante, i);
            return; // Termina la búsqueda después de encontrar el primer estudiante
        }
    }

    JOptionPane.showMessageDialog(
            GestiondeNotasEstudiantes.this,
            "Estudiante no encontrado.",
            "Búsqueda Secuencial",
            JOptionPane.INFORMATION_MESSAGE
    );
}

private void buscarEstudianteBinaria() {
    // Verifica si la lista está ordenada antes de realizar la búsqueda binaria
    if (estaOrdenada(listaEstudiantes)) {
        // Ingrese el promedio como String desde el cuadro de diálogo
        String promedioInput = JOptionPane.showInputDialog("Ingrese el promedio de búsqueda:");

        // Reemplazar comas por puntos en el String antes de convertir a double
        promedioInput = promedioInput.replace(",", ".");

        try {
            // Convertir a double y redondear a dos decimales
            double promedioBusqueda = Math.round(Double.parseDouble(promedioInput) * 100.0) / 100.0;

            int indice = busquedaBinaria(listaEstudiantes, promedioBusqueda);

            if (indice != -1) {
                mostrarInformacionEstudiante(listaEstudiantes.get(indice), indice);
            } else {
                JOptionPane.showMessageDialog(
                        GestiondeNotasEstudiantes.this,
                        "Estudiante no encontrado.",
                        "Búsqueda Binaria",
                        JOptionPane.INFORMATION_MESSAGE
                );
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    GestiondeNotasEstudiantes.this,
                    "Formato de número no válido. Ingrese un número válido.",
                    "Búsqueda Binaria",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    } else {
        JOptionPane.showMessageDialog(
                GestiondeNotasEstudiantes.this,
                "La lista debe estar ordenada para realizar una búsqueda binaria.",
                "Búsqueda Binaria",
                JOptionPane.WARNING_MESSAGE
        );
    }
}

private void mostrarInformacionEstudiante(Estudiantes estudiante, int posicion) {
    JOptionPane.showMessageDialog(
            GestiondeNotasEstudiantes.this,
            "Estudiante encontrado en la posición " + (posicion + 1) + ":\n" +
                    "Nombre: " + estudiante.getNombre() + "\n" +
                    "Apellido: " + estudiante.getApellido() + "\n" +
                    "Promedio: " + String.format("%.2f", estudiante.getPromedio()),
            "Información del Estudiante",
            JOptionPane.INFORMATION_MESSAGE
    );
}

    private boolean estaOrdenada(List<Estudiantes> lista) {
        for (int i = 1; i < lista.size(); i++) {
            if (lista.get(i - 1).getPromedio() > lista.get(i).getPromedio()) {
                return false;
            }
        }
        return true;
    }

    private int busquedaBinaria(List<Estudiantes> lista, double promedioBusqueda) {
        int izquierda = 0;
        int derecha = lista.size() - 1;

        while (izquierda <= derecha) {
            int medio = (izquierda + derecha) / 2;
            double promedioMedio = lista.get(medio).getPromedio();

            if (promedioMedio == promedioBusqueda) {
                return medio; // Encontrado
            } else if (promedioMedio < promedioBusqueda) {
                izquierda = medio + 1;
            } else {
                derecha = medio - 1;
            }
        }

        return -1; // No encontrado
    }
    

}
     