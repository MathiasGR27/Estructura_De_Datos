package gestionestudiantes;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import javax.swing.table.JTableHeader;

public class Matriculacion extends JFrame {

    private JTextField NRcMateriasTextField;
    private JTextField semestreTextField;
    private JTextField nombreMateriaTextField;
    private JTextField nombreIngenieroTextField;
    private DefaultTableModel modeloTabla;

    public Matriculacion() {
        // Configuración de la ventana
        setTitle("Matriculación");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);


        // Crear componentes de la interfaz
        NRcMateriasTextField = new JTextField(10);
        semestreTextField = new JTextField(10);
        nombreMateriaTextField = new JTextField(10);
        nombreIngenieroTextField = new JTextField(10);
        JButton guardarButton = new JButton("Guardar");
        JButton eliminarButton = new JButton("Eliminar");
        JButton actualizarButton = new JButton("Actualizar");
        JButton salirButton = new JButton("Salir");

        // Configurar la tabla
        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("NRC de la Materia");
        modeloTabla.addColumn("Semestre");
        modeloTabla.addColumn("Materia");
        modeloTabla.addColumn("Ingeniero ");

        JTable tabla = new JTable(modeloTabla);
        JTableHeader header = tabla.getTableHeader();
        header.setBackground(new Color(173, 216, 230));  // Puedes cambiar los valores RGB según tus preferencias
        JScrollPane scrollPane = new JScrollPane(tabla);

        // Configurar colores para botones
        Color colorInicial = new Color(173, 216, 230); // Celeste
        Color colorResaltado = new Color(0, 255, 255); // Azul

        guardarButton.setBackground(colorInicial);
        eliminarButton.setBackground(colorInicial);
        actualizarButton.setBackground(colorInicial);
        salirButton.setBackground(colorInicial);

        // Configurar eventos para cambiar el color al pasar el mouse
        MouseAdapter colorChangeAdapter = new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ((JButton) evt.getSource()).setBackground(colorResaltado);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                ((JButton) evt.getSource()).setBackground(colorInicial);
            }
        };

        guardarButton.addMouseListener(colorChangeAdapter);
        eliminarButton.addMouseListener(colorChangeAdapter);
        actualizarButton.addMouseListener(colorChangeAdapter);
        salirButton.addMouseListener(colorChangeAdapter);

        // Configurar eventos para los botones
        guardarButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        // Obtener los valores de los campos
        String nrcMaterias = NRcMateriasTextField.getText().trim();
        String semestre = semestreTextField.getText().trim();
        String nombreMateria = nombreMateriaTextField.getText().trim();
        String nombreIngeniero = nombreIngenieroTextField.getText().trim();

        // Validar que el NRC de la Materia sea un número
        if (!nrcMaterias.matches("\\d+")) {
            JOptionPane.showMessageDialog(null, "El NRC de la Materia debe ser un número.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validar que el Semestre no contenga números
        if (semestre.matches(".*\\d+.*")) {
            JOptionPane.showMessageDialog(null, "El Semestre no debe contener números.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validar que el Nombre de la Materia y el Nombre del Ingeniero no contengan números
        if (nombreMateria.matches(".*\\d+.*") || nombreIngeniero.matches(".*\\d+.*")) {
            JOptionPane.showMessageDialog(null, "El Nombre de la Materia y el Nombre del Ingeniero no deben contener números.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (modeloTabla.getRowCount() >= 6) {
            JOptionPane.showMessageDialog(null, "Ya ha alcanzado el límite de 6 materias matriculadas.", "Aviso", JOptionPane.WARNING_MESSAGE);
        } else {
            // Agregar información a la tabla
            Object[] fila = {nrcMaterias, semestre, nombreMateria, nombreIngeniero};
            modeloTabla.addRow(fila);

            // Utilizar la instancia existente de Conexion
            Conexion conexion = new Conexion();
            conexion.insertarMatricula(new matriculas(Integer.parseInt(nrcMaterias), semestre, nombreMateria, nombreIngeniero));

            // Limpiar los campos después de la inserción 
            NRcMateriasTextField.setText("");
            semestreTextField.setText("");
            nombreMateriaTextField.setText("");
            nombreIngenieroTextField.setText("");
        }
    }
});
        
         eliminarButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        int filaSeleccionada = tabla.getSelectedRow();

        if (filaSeleccionada != -1) {
            // Obtener el NRC de la fila seleccionada
            Object nrcObject = tabla.getValueAt(filaSeleccionada, 0);

            // Verificar si el valor es de tipo Integer o String
            if (nrcObject instanceof Integer) {
                int nrcMaterias = (int) nrcObject;

                // Eliminar de la base de datos utilizando la instancia de Conexion
                Conexion conexion = new Conexion();
                conexion.eliminarMatricula(nrcMaterias);

                // Remover la fila de la tabla
                modeloTabla.removeRow(filaSeleccionada);
            } else if (nrcObject instanceof String) {
                try {
                    int nrcMaterias = Integer.parseInt((String) nrcObject);

                    // Eliminar de la base de datos utilizando la instancia de Conexion
                    Conexion conexion = new Conexion();
                    conexion.eliminarMatricula(nrcMaterias);

                    // Remover la fila de la tabla
                    modeloTabla.removeRow(filaSeleccionada);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "El valor del NRC no es un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione una fila para eliminar.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }
});
        actualizarButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        int filaSeleccionada = tabla.getSelectedRow();

        if (filaSeleccionada != -1) {
            // Obtener los valores de los campos
            String nuevoNrcMaterias = NRcMateriasTextField.getText().trim();
            String nuevoSemestre = semestreTextField.getText().trim();
            String nuevoNombreMateria = nombreMateriaTextField.getText().trim();
            String nuevoNombreIngeniero = nombreIngenieroTextField.getText().trim();

            // Validar que el nuevo NRC de la Materia sea un número
            if (!nuevoNrcMaterias.matches("\\d+")) {
                JOptionPane.showMessageDialog(null, "El nuevo NRC de la Materia debe ser un número.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Validar que el nuevo Semestre no contenga números
            if (nuevoSemestre.matches(".*\\d+.*")) {
                JOptionPane.showMessageDialog(null, "El nuevo Semestre no debe contener números.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Validar que el Nuevo Nombre de la Materia y el Nuevo Nombre del Ingeniero no contengan números
            if (nuevoNombreMateria.matches(".*\\d+.*") || nuevoNombreIngeniero.matches(".*\\d+.*")) {
                JOptionPane.showMessageDialog(null, "El Nuevo Nombre de la Materia y el Nuevo Nombre del Ingeniero no deben contener números.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Actualizar la fila en la tabla
            modeloTabla.setValueAt(Integer.parseInt(nuevoNrcMaterias), filaSeleccionada, 0);
            modeloTabla.setValueAt(nuevoSemestre, filaSeleccionada, 1);
            modeloTabla.setValueAt(nuevoNombreMateria, filaSeleccionada, 2);
            modeloTabla.setValueAt(nuevoNombreIngeniero, filaSeleccionada, 3);

            // Actualizar en la base de datos utilizando la instancia de Conexion
            matriculas nuevaMatricula = new matriculas(Integer.parseInt(nuevoNrcMaterias), nuevoSemestre, nuevoNombreMateria, nuevoNombreIngeniero);
            Conexion conexion = new Conexion();
            conexion.actualizarMatricula(Integer.parseInt(nuevoNrcMaterias), nuevaMatricula);

            // Limpiar los campos después de la actualización (opcional)
            NRcMateriasTextField.setText("");
            semestreTextField.setText("");
            nombreMateriaTextField.setText("");
            nombreIngenieroTextField.setText("");
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione una fila para actualizar.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }
});
        

        salirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                GestionEstudiantes1.obtenerInstancia().mostrarVentana(); // Mostrar la ventana de MenuFormularios
            }
        });

        // Configurar el diseño de la interfaz
        JPanel panel = new JPanel(new GridLayout(7, 2, 5, 5));
        panel.add(new JLabel("NRC de la Materia :"));
        panel.add(NRcMateriasTextField);
        panel.add(new JLabel("Semestre:"));
        panel.add(semestreTextField);
        panel.add(new JLabel("Nombre de la Materia:"));
        panel.add(nombreMateriaTextField);
        panel.add(new JLabel("Nombre del Ingeniero:"));
        panel.add(nombreIngenieroTextField);
        panel.add(guardarButton);
        panel.add(eliminarButton);
        panel.add(actualizarButton);
        panel.add(salirButton);

        // Agregar el panel y el JScrollPane a la ventana
        add(panel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
    }
}