package gestionestudiantes;

import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Collections;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import java.util.Date;
import java.util.List;

public class GenerarReporte {

   public static void generarInforme(String nombreArchivo) {
    Document document = new Document();

    try {
        
        PdfWriter.getInstance(document, new FileOutputStream(nombreArchivo));
        document.open();
        
         // Agregar imagen centrada
        Image image = Image.getInstance("E:\\Codigos Estructura\\GestionEstudiantes\\LogoEspe.png");
        image.setAlignment(Image.ALIGN_CENTER); // Alinea la imagen al centro
        image.scaleToFit(170, 200); // Ajusta el tamaño de la imagen
        document.add(image);
        
        // Agregar encabezado personalizado
        String currentDate = new SimpleDateFormat("dd/MM/yyyy").format(new Date());//Nos sirve ´para el momento de ejecutar nos salga la fecha de la ejecucion
        String headerText = "INFORME DE ESTUDIANTES\n\n"
            + "Fecha: " + currentDate + "\n";
        Paragraph header = new Paragraph(headerText);
        header.setAlignment(Paragraph.ALIGN_CENTER); // Alinea el encabezado al centro
        document.add(header);

       
        Conexion conexionMongoDB = new Conexion();
        
        document.add(new Paragraph("\n Lista de todos los estudiantes de diferentes carreras:"));
        
        Chunk chunk = new Chunk("\n");//Genera un salto linea 
        document.add(chunk);
        
        List<String> carrerasDisponibles = conexionMongoDB.obtenerCarrerasDisponibles();

        // Obtener todos los estudiantes
        
        List<Estudiantes> todosEstudiantes = conexionMongoDB.obtenerTodosEstudiantes();

        // Crear tabla para los datos de estudiantes
        PdfPTable pdfTable = new PdfPTable(4); // Ajusta según la cantidad de columnas necesarias
        pdfTable.setWidthPercentage(100);
        
        // Agregar encabezados de columna
        String[] columnNames = {"Nombre", "Apellido", "Promedio", "Carrera"};
        for (String columnName : columnNames) {
            PdfPCell cell = new PdfPCell(new Phrase(columnName));
            cell.setBackgroundColor(BaseColor.CYAN);
            pdfTable.addCell(cell);
        }

        // Agregar filas de datos para todos los estudiantes
        for (Estudiantes estudiante : todosEstudiantes) {
            pdfTable.addCell(new Phrase(estudiante.getNombre()));
            pdfTable.addCell(new Phrase(estudiante.getApellido()));
            pdfTable.addCell(new Phrase(String.format("%.2f", estudiante.getPromedio())));
            pdfTable.addCell(new Phrase(estudiante.getCarrera()));
        }

        document.add(pdfTable);
        document.add(Chunk.NEWLINE); // Agregar espacio entre la lista de estudiantes y las carreras

        for (String carrera : carrerasDisponibles) {
            document.add(new Phrase("Mejorez Promedio de la Carrera: " + carrera + "\n"));

            List<Estudiantes> mejoresPromedios = conexionMongoDB.obtenerMejoresPromedios(carrera);

            // Crear tabla para los datos de estudiantes de la carrera actual
            PdfPTable pdfTableCarrera = new PdfPTable(4);
            pdfTableCarrera.setWidthPercentage(100);
            
            

            // Agregar encabezados de columna para la carrera actual
            for (String columnName : columnNames) {
                PdfPCell cell = new PdfPCell(new Phrase(columnName));
                cell.setBackgroundColor(BaseColor.CYAN);
                pdfTableCarrera.addCell(cell);
            }

            // Agregar filas de datos para los mejores estudiantes de la carrera actual
            for (Estudiantes estudiante : mejoresPromedios) {
                
                pdfTableCarrera.addCell(new Phrase(estudiante.getNombre()));
                pdfTableCarrera.addCell(new Phrase(estudiante.getApellido()));
                pdfTableCarrera.addCell(new Phrase(String.format("%.2f", estudiante.getPromedio())));
                pdfTableCarrera.addCell(new Phrase(estudiante.getCarrera()));
            }

            document.add(pdfTableCarrera);
            document.add(Chunk.NEWLINE); // Agregar espacio entre carreras
        }

        System.out.println("PDF generado exitosamente: " + nombreArchivo);

    } catch (DocumentException | java.io.IOException ex) {
        ex.printStackTrace();
    } finally {
        document.close();
    }
}
}
           