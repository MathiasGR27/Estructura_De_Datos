package gestionestudiantes;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.util.List;
import javax.swing.table.JTableHeader;

public class MejoresPromedio extends JFrame {

    private JPanel panelResultados;
    private JTable tablaResultados;

    public MejoresPromedio() {
        super("Mejores Promedios");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 400);

        JLabel carreraLabel = new JLabel("Ingrese la carrera:");
        JTextField carreraTextField = new JTextField(20);
        JButton mejorespromediosButton = new JButton("Mostrar los mejores promedios");
        JButton salirButton = new JButton("Salir");

        panelResultados = new JPanel();
        tablaResultados = new JTable();

        // Configurar el diseño del formulario
        JPanel panelPrincipal = new JPanel(new GridLayout(5, 1, 10, 10));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Agregar elementos al panel principal
        panelPrincipal.add(carreraLabel);
        panelPrincipal.add(carreraTextField);
        panelPrincipal.add(mejorespromediosButton);
        panelPrincipal.add(salirButton);  // Agregar el botón de salir

        // Agregar el panel principal al BorderLayout
        add(panelPrincipal, BorderLayout.NORTH);

        // Configurar el modelo de la tabla
        DefaultTableModel modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("Nombre");
        modeloTabla.addColumn("Apellido");
        modeloTabla.addColumn("Promedio");

        // Configurar la tabla
        tablaResultados.setBackground(Color.white); // Cambiar el color de fondo de la tabla
        tablaResultados.setModel(modeloTabla);
        DefaultTableCellRenderer renderizador = new DefaultTableCellRenderer();
        renderizador.setHorizontalAlignment(JLabel.CENTER);
        tablaResultados.getColumnModel().getColumn(2).setCellRenderer(renderizador);

        // Configurar el evento del botón de mostrar promedios
        mejorespromediosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String carreraSeleccionada = carreraTextField.getText();

                if (carreraSeleccionada != null && !carreraSeleccionada.isEmpty()) {
                    Conexion conexion = new Conexion();
                    List<Estudiantes> mejoresPromedios = conexion.obtenerTresMejoresPromedios(carreraSeleccionada);

                    if (mejoresPromedios.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "No hay estudiantes de esa carrera.", "Aviso", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        mostrarResultados(mejoresPromedios);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Debe ingresar una carrera válida.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
        });

        // Configurar el evento del botón de salir
        salirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Cerrar la ventana actual (la de Periodo)
                GestionEstudiantes1.obtenerInstancia().mostrarVentana(); // Mostrar la ventana de MenuFormularios
            }
        });

        // Configurar el JScrollPane para la tabla
        JScrollPane scrollPane = new JScrollPane(tablaResultados);
        add(scrollPane, BorderLayout.CENTER);

        // HSB: (180, 0.29, 0.90)
        float[] hsb = {180f / 360f, 0.29f, 0.90f};
        Color celesteHSB = Color.getHSBColor(hsb[0], hsb[1], hsb[2]);

        // Cambiar el color de fondo del encabezado de la tabla
        JTableHeader header = tablaResultados.getTableHeader();
        header.setBackground(celesteHSB);

        // Configuración de colores para botones
        
        
        Color colorInicial = celesteHSB;// Celeste
        Color colorResaltado = new Color(0, 255, 255);  // Azul

        // Establecer el color inicial para los botones
        mejorespromediosButton.setBackground(colorInicial);
        salirButton.setBackground(colorInicial);

        // Configurar eventos para cambiar el color al pasar el mouse
        MouseAdapter colorChangeAdapter = new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ((JButton) evt.getSource()).setBackground(colorResaltado);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                ((JButton) evt.getSource()).setBackground(colorInicial);
            }
        };

        mejorespromediosButton.addMouseListener(colorChangeAdapter);
        salirButton.addMouseListener(colorChangeAdapter);

        setLocationRelativeTo(null); // Centrar la ventana en la pantalla
        setVisible(true); // Hacer visible la ventana
    }

    public void mostrarResultados(List<Estudiantes> mejoresPromedios) {
        DefaultTableModel modeloTabla = (DefaultTableModel) tablaResultados.getModel();
        modeloTabla.setRowCount(0);

        for (Estudiantes estudiante : mejoresPromedios) {
            Object[] fila = {estudiante.getNombre(), estudiante.getApellido(), String.format("%.2f", estudiante.getPromedio())};
            modeloTabla.addRow(fila);
        }
    }
}