package gestionestudiantes;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import javax.swing.table.JTableHeader;


public class Periodo extends JFrame {
    
    private JTextField periodoTextField;
    private JComboBox<String> carreraComboBox;
    private DefaultTableModel modeloTabla;

    public Periodo() {
        // Configuración de la ventana principal
        setTitle("Gestión de Periodos");
        setSize(950, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        periodoTextField = new JTextField(10);
        String[] carreras = {"ITIN", "BIOTECNOLOGIA", "AGROPECUARIA"};
        carreraComboBox = new JComboBox<>(carreras);
        JButton guardarButton = new JButton("Agregar y Guardar");
        JButton eliminarButton = new JButton("Eliminar");
        JButton actualizarButton = new JButton("Actualizar");
        JButton salirButton = new JButton("Salir");

        // Configurar la tabla
        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("Periodo");
        modeloTabla.addColumn("Carrera");

        // Configurar la tabla

        JTable tabla = new JTable(modeloTabla);
        JTableHeader header = tabla.getTableHeader();
        header.setBackground(new Color(173, 216, 230));  // Puedes cambiar los valores RGB según tus preferencias
        JScrollPane scrollPane = new JScrollPane(tabla);
        

        // Crear el panel de entrada de datos con los nuevos campos
        JPanel panelEntradaDatos = new JPanel(new GridLayout(5, 2, 5, 5));
        panelEntradaDatos.add(new JLabel("Periodo:"));
        panelEntradaDatos.add(periodoTextField);
        panelEntradaDatos.add(new JLabel("Carrera:"));
        panelEntradaDatos.add(carreraComboBox);

        JPanel panelBotones = new JPanel(new FlowLayout());
        panelBotones.add(guardarButton);
        panelBotones.add(eliminarButton);
        panelBotones.add(actualizarButton);
        panelBotones.add(salirButton);

        // Configurar el diseño del formulario
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setDividerLocation(500);

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.CYAN);
        panel.add(panelEntradaDatos, BorderLayout.CENTER);
        panel.add(panelBotones, BorderLayout.SOUTH);

        JPanel panelDerecho = new JPanel(new BorderLayout());
        panelDerecho.setBackground(Color.GRAY);
        panelDerecho.add(scrollPane, BorderLayout.CENTER);

        splitPane.setLeftComponent(panel);
        splitPane.setRightComponent(panelDerecho);

        add(splitPane);

        // Configuración de colores para botones
        Color colorInicial = new Color(173, 216, 230); // Celeste
        Color colorResaltado = new Color(0, 255, 255);    // Azul

        // Establecer el color inicial para los botones
        guardarButton.setBackground(colorInicial);
        eliminarButton.setBackground(colorInicial);
        actualizarButton.setBackground(colorInicial);
        salirButton.setBackground(colorInicial);

        // Configurar eventos para cambiar el color al pasar el mouse
        MouseAdapter colorChangeAdapter = new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ((JButton) evt.getSource()).setBackground(colorResaltado);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                ((JButton) evt.getSource()).setBackground(colorInicial);
            }
        };

        guardarButton.addMouseListener(colorChangeAdapter);
        eliminarButton.addMouseListener(colorChangeAdapter);
        actualizarButton.addMouseListener(colorChangeAdapter);
        salirButton.addMouseListener(colorChangeAdapter);

        guardarButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        // Obtener los valores de los campos
        String periodo = periodoTextField.getText().trim();
        String carrera = (String) carreraComboBox.getSelectedItem();

        // Validar que el periodo solo contenga números y caracteres especiales
        if (!periodo.matches("[0-9\\-]+")) {
            JOptionPane.showMessageDialog(null, "El periodo debe contener solo números y el carácter especial '-'.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Llamar al método de la clase Conexion para insertar el nuevo periodo en la base de datos
        Conexion conexion = new Conexion();
        conexion.insertarPeriodo(periodo, carrera);

        // Agregar información a la tabla
        Object[] fila = {periodo, carrera};
        modeloTabla.addRow(fila);

        // Limpiar los campos después de la inserción (opcional)
        periodoTextField.setText("");
        carreraComboBox.setSelectedItem(null);
    }
});

        eliminarButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        int filaSeleccionada = tabla.getSelectedRow();

        if (filaSeleccionada != -1) {
            // Obtener el nombre del periodo a eliminar
            String periodoAEliminar = (String) tabla.getValueAt(filaSeleccionada, 0);

            // Llamar al método de la clase Conexion para eliminar el periodo en la base de datos
            Conexion conexion = new Conexion();
            conexion.eliminarPeriodo(periodoAEliminar);

            // Remover la fila de la tabla
            modeloTabla.removeRow(filaSeleccionada);
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione una fila para eliminar.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }
});

     actualizarButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        int filaSeleccionada = tabla.getSelectedRow();

        if (filaSeleccionada != -1) {
            // Obtener los valores de los campos
            String nombreAntiguo = (String) tabla.getValueAt(filaSeleccionada, 0);
            String nuevoPeriodo = periodoTextField.getText().trim();
            String nuevaCarrera = (String) carreraComboBox.getSelectedItem();

            // Validar que el nuevo periodo solo contenga números y caracteres especiales
            if (!nuevoPeriodo.matches("[0-9\\-]+")) {
                JOptionPane.showMessageDialog(null, "El nuevo periodo debe contener solo números y el carácter especial '-'.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Llamar al método de la clase Conexion para actualizar el periodo en la base de datos
            Conexion conexion = new Conexion();
            conexion.actualizarPeriodo(nombreAntiguo, nuevoPeriodo, nuevaCarrera);

            // Actualizar la fila en la tabla
            tabla.setValueAt(nuevoPeriodo, filaSeleccionada, 0);
            tabla.setValueAt(nuevaCarrera, filaSeleccionada, 1);

            // Limpiar los campos después de la actualización (opcional)
            periodoTextField.setText("");
            carreraComboBox.setSelectedItem(null);
        } else {
            JOptionPane.showMessageDialog(null, "Seleccione una fila para actualizar.", "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }
});

        salirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Cerrar la ventana actual (la de Periodo)
                GestionEstudiantes1.obtenerInstancia().mostrarVentana(); // Mostrar la ventana de MenuFormularios
            }
        });
    }

}