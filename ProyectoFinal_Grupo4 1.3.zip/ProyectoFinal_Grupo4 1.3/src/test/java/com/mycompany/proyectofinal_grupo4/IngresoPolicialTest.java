/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.proyectofinal_grupo4;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.concurrent.CountDownLatch;
import javax.swing.SwingUtilities;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Usuario
 */
public class IngresoPolicialTest {
    
    public IngresoPolicialTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    @Test
    void testGuardarDatos() {
        System.out.println("testGuardarDatos");       
        IngresoPolicial instance1 = new IngresoPolicial();
        // llama al método y luego verifica que algún estado ha cambiado
        assertTrue(instance1.guardarDatos());
    }

    /**
     * Test of eliminarDatos method, of class IngresoPolicia.
     */
    @Test
    void testEliminarDatos() {
        System.out.println("testEliminarDatos");
        IngresoPolicial instance = new IngresoPolicial();  
        // Agregar un usuario para que haya algo para eliminar
        instance.guardarDatos();
        // Lógica de prueba: llama al método y luego verifica que algún estado ha cambiado
        assertTrue(instance.eliminarDatos());
    }

    /**
     * Test of actualizarDatos method, of class IngresoPolicia.
     */
    @Test
    void testActualizarDatos() {
        System.out.println("testActualizarDatos");
        IngresoPolicial instance = new IngresoPolicial();  
        // Agregar un usuario para que haya algo para actualizar
        instance.guardarDatos();
        // Lógica de prueba: llama al método y luego verifica que algún estado ha cambiado
        assertTrue(instance.actualizarDatos());
    }

    /**
     * Test of limpiarDatos method, of class IngresoPolicia.
     */
    @Test
    void testLimpiarDatos() {
        System.out.println("testLimpiarDatos");
        IngresoPolicial instance = new IngresoPolicial();
        // Lógica de prueba: llama al método y luego verifica que algún estado ha cambiado
        assertTrue(instance.limpiarDatos());
    }

    /**
     * Test of agregarDatosTabla method, of class IngresoPolicia.
     */
    @Test
    void testAgregarDatosTabla() {
        System.out.println("testAgregarDatosTabla");
        IngresoPolicial instance = new IngresoPolicial();
        
        // Lógica de prueba: llama al método y luego verifica que algún estado ha cambiado
        assertTrue(instance.agregarDatosTabla());
    }

    /**
     * Test of cargarDatosEnTabla method, of class IngresoPolicia.
     */
    @Test
    void testCargarDatosEnTabla() {
        System.out.println("testCargarDatosEnTabla");
        IngresoPolicial instance = new IngresoPolicial();
        
        // Lógica de prueba: llama al método y luego verifica que algún estado ha cambiado
        assertTrue(instance.cargarDatosEnTabla());
    }

    /**
     * Test of main method, of class IngresoPolicia.
     */
    @Test
    public void testMain() {
        System.out.println("testMain");

        CountDownLatch latch = new CountDownLatch(1);

        SwingUtilities.invokeLater(() -> {
            IngresoPolicial ingreso = new IngresoPolicial();
            ingreso.setVisible(true);

            ingreso.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosed(WindowEvent e) {
                    // La interfaz se ha cerrado, reducimos el recuento del latch
                    latch.countDown();
                }
            });
        });

        try {
            // Espera hasta que el usuario cierre la interfaz
            latch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}