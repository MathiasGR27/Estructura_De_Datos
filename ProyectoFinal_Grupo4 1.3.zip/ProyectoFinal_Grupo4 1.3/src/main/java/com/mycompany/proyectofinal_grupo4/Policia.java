/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectofinal_grupo4;

/**
 *
 * @author Usuario
 */
public class Policia {
    private String nombre;
    private long cedula; // Cambiado a long
    private long celular; // Cambiado a long
    private String fechanacimiento;

    public Policia(String nombre, long cedula, long celular, String fechanacimiento) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.celular = celular;
        this.fechanacimiento = fechanacimiento;
    }
    
    public Policia(){
        
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public long getCedula() {
        return cedula;
    }

    public void setCedula(long cedula) {
        this.cedula = cedula;
    }

    public long getCelular() {
        return celular;
    }

    public void setCelular(long celular) {
        this.celular = celular;
    }

    public String getFechanacimiento() {
        return fechanacimiento;
    }

    public void setFechanacimiento(String fechanacimiento) {
        this.fechanacimiento = fechanacimiento;
    }
}
