/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.proyectofinal_grupo4;

import control.Conexion;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.lang.String;

/**
 *
 * @author Usuario
 */
public class VerDatosIngresados extends javax.swing.JFrame {
    
    private String nombre;
    private long cedula;
    private String nombreSeleccionado;
    private long cedulaSeleccionada;
    private Conexion conexion = new Conexion();
    private DefaultTableModel model;


    public VerDatosIngresados() {
        initComponents();
        this.setLocationRelativeTo(null);
    }


    @SuppressWarnings("unchecked")
    
     
    public String getNombreSeleccionado() {
        return nombreSeleccionado;
    }

    public long getCedulaSeleccionada() {
        return cedulaSeleccionada;
    }
    
    public String getNombreadmiSeleccionado() {
        return nombreSeleccionado;
    }

    public long getCedulaadmiSeleccionada() {
        return cedulaSeleccionada;
    }
    
    public boolean buscarDatos() {
    try {
        String cedulaABuscar = txtCedula.getText().trim();
        if (cedulaABuscar.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese una cédula para buscar.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        long cedula;
        try {
            cedula = Long.parseLong(cedulaABuscar);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La cédula debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        List<DatosPolicia> resultados = conexion.buscarpoliciaPorCedula(cedulaABuscar);

        if (resultados.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No se encontraron policías con la cédula especificada.", "Información", JOptionPane.INFORMATION_MESSAGE);
            return false;
        }

        DatosPolicia resultado = resultados.get(0); // Supongamos que solo mostraremos el primer resultado si hay varios

        // Guardar nombre y cédula en variables temporales
        this.nombreSeleccionado = resultado.getNombre();
        cedulaSeleccionada = resultado.getCedula();

        // Mostrar resultados en cajas de texto
        txtNombre.setText(resultado.getNombre());
        txtCedula.setText(String.valueOf(resultado.getCedula()));
        txtCelular.setText(String.valueOf(resultado.getCelular()));
        choFechaNacimiento.setDate(new SimpleDateFormat("dd/MM/yyyy").parse(resultado.getFechanacimiento())); // Suponiendo que la fecha está en formato "dd/MM/yyyy"
        jComboBox1.setSelectedItem(resultado.getCategoria());

        JOptionPane.showMessageDialog(this, "Se encontraron policías con la cédula especificada.", "Información", JOptionPane.INFORMATION_MESSAGE);

        return true;
    } catch (Exception e) {
        mostrarError("Error al buscar datos", e);
        return false;
    }
}
    private void mostrarError(String mensaje, Exception e) {
        JOptionPane.showMessageDialog(this, mensaje + "\n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
    
   
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        txtCedula = new javax.swing.JTextField();
        txtCelular = new javax.swing.JTextField();
        choFechaNacimiento = new com.toedter.calendar.JDateChooser();
        jComboBox1 = new javax.swing.JComboBox<>();
        jSeparator4 = new javax.swing.JSeparator();
        jPanel6 = new javax.swing.JPanel();
        btnAsignar = new javax.swing.JButton();
        btnMenu1 = new javax.swing.JButton();
        btnBuscar7 = new javax.swing.JButton();
        jSeparator7 = new javax.swing.JSeparator();
        jSeparator8 = new javax.swing.JSeparator();
        jSeparator9 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 3));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel14.setText("Numero de Celular");
        jLabel14.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 200, 196, 20));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel15.setText("Nombre y Apellido:");
        jLabel15.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel2.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 160, 196, 20));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel16.setText("Ingrese su numero de cedula");
        jLabel16.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel2.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 120, -1, 20));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel17.setText("Fecha de Nacimiento:");
        jLabel17.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel2.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 240, 196, 20));

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel18.setText("Categoria");
        jLabel18.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel2.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 280, 196, 20));

        txtNombre.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        txtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNombreKeyTyped(evt);
            }
        });
        jPanel2.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 160, 261, 20));

        txtCedula.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        txtCedula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCedulaActionPerformed(evt);
            }
        });
        txtCedula.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCedulaKeyTyped(evt);
            }
        });
        jPanel2.add(txtCedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 120, 261, 20));

        txtCelular.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        txtCelular.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCelularKeyTyped(evt);
            }
        });
        jPanel2.add(txtCelular, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 200, 261, 20));

        choFechaNacimiento.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel2.add(choFechaNacimiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 240, 260, 20));

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Policial", "Administrativo" }));
        jComboBox1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel2.add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 280, 261, 20));

        jSeparator4.setForeground(new java.awt.Color(12, 92, 235));
        jSeparator4.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jPanel2.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 120, 20, 180));

        jPanel6.setBackground(new java.awt.Color(0, 51, 153));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnAsignar.setBackground(new java.awt.Color(0, 51, 153));
        btnAsignar.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btnAsignar.setForeground(new java.awt.Color(255, 255, 255));
        btnAsignar.setText("ASIGNAR ");
        btnAsignar.setBorder(null);
        btnAsignar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAsignarActionPerformed(evt);
            }
        });
        jPanel6.add(btnAsignar, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 220, 120, 30));

        btnMenu1.setBackground(new java.awt.Color(0, 51, 153));
        btnMenu1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btnMenu1.setForeground(new java.awt.Color(255, 255, 255));
        btnMenu1.setText("MENÚ");
        btnMenu1.setBorder(null);
        btnMenu1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMenu1ActionPerformed(evt);
            }
        });
        jPanel6.add(btnMenu1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 270, 80, 30));

        btnBuscar7.setBackground(new java.awt.Color(0, 51, 153));
        btnBuscar7.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btnBuscar7.setForeground(new java.awt.Color(255, 255, 255));
        btnBuscar7.setText("BUSCAR");
        btnBuscar7.setBorder(null);
        btnBuscar7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscar7ActionPerformed(evt);
            }
        });
        jPanel6.add(btnBuscar7, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 170, -1, 30));

        jSeparator7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.add(jSeparator7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 250, 120, 20));

        jSeparator8.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.add(jSeparator8, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, 120, 20));

        jSeparator9.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.add(jSeparator9, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 300, 120, 10));

        jLabel1.setIcon(new javax.swing.ImageIcon("D:\\ProyectoFinal_Grupo4\\src\\main\\java\\imagenes\\logopolicia.jpg")); // NOI18N
        jLabel1.setText("jLabel1");
        jPanel6.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 150, 150));

        jPanel2.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 190, 320));

        jPanel7.setBackground(new java.awt.Color(0, 51, 153));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("CONSULTAR DATOS DEL PERSONAL ");
        jPanel7.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 30, -1, 39));

        jPanel2.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 0, 530, 90));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 710, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtNombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreKeyTyped
        char c = evt.getKeyChar();
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == KeyEvent.VK_BACK_SPACE || c == KeyEvent.VK_SPACE)) {
            evt.consume();
        }
    }//GEN-LAST:event_txtNombreKeyTyped

    private void txtCedulaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCedulaKeyTyped
        char c = evt.getKeyChar();
        if (!Character.isDigit(c) && c != '.'){
            evt.consume();
        }
    }//GEN-LAST:event_txtCedulaKeyTyped

    private void txtCelularKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCelularKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCelularKeyTyped

    private void txtCedulaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCedulaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCedulaActionPerformed

    private void btnAsignarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAsignarActionPerformed
        try {
        String categoriaSeleccionada = jComboBox1.getSelectedItem().toString();

        // Obtener nombre y cédula seleccionados
        String nombreSeleccionado = getNombreSeleccionado();
        long cedulaSeleccionada = getCedulaSeleccionada();
        
        String nombreSeleccionadoadmi = getNombreadmiSeleccionado();
        long cedulaSeleccionadaadmi = getCedulaadmiSeleccionada();

        if ("Policial".equals(categoriaSeleccionada)) {
            ActividadesPolicia distribuir = new ActividadesPolicia();
            distribuir.setNombreYCedula(nombreSeleccionado, cedulaSeleccionada);
            distribuir.setVisible(true);
            this.dispose();
     
        } else if ("Administrativo".equals(categoriaSeleccionada)) {
            ActividadesAdministrativos distribuir = new ActividadesAdministrativos();
            distribuir.setNombreYCedula(nombreSeleccionadoadmi, cedulaSeleccionadaadmi);
            distribuir.setVisible(true);
            this.dispose();
        } else {
            
            JOptionPane.showMessageDialog(this, "Categoría no reconocida", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (Exception e) {
        mostrarError("Error al asignar actividades", e);
    }
    }//GEN-LAST:event_btnAsignarActionPerformed

    private void btnMenu1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMenu1ActionPerformed
        // TODO add your handling code here:
        MenuPractica1 menu = new MenuPractica1();
        menu.setVisible(true);
        this.dispose();
                
    }//GEN-LAST:event_btnMenu1ActionPerformed

    private void btnBuscar7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscar7ActionPerformed
        // TODO add your handling code here:
        buscarDatos();
    }//GEN-LAST:event_btnBuscar7ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VerDatosIngresados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VerDatosIngresados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VerDatosIngresados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VerDatosIngresados.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VerDatosIngresados().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAsignar;
    private javax.swing.JButton btnBuscar7;
    private javax.swing.JButton btnMenu1;
    private com.toedter.calendar.JDateChooser choFechaNacimiento;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JTextField txtCedula;
    private javax.swing.JTextField txtCelular;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables
}
