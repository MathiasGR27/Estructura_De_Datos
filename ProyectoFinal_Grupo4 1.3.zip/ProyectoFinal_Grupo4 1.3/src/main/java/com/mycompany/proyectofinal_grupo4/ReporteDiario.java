package com.mycompany.proyectofinal_grupo4;

import control.Conexion;
import java.awt.event.KeyEvent;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfPCell;
import java.io.File;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfGState;
import com.itextpdf.text.pdf.PdfPageEventHelper;

/**
 *
 * @author Usuario
 */
public class ReporteDiario extends javax.swing.JFrame {

    private Conexion conexion = new Conexion();
    private DefaultTableModel model;

    public ReporteDiario() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")

    public boolean generarreporte() {
        try {
            // Obtener la cédula del campo correspondiente
            String cedula = txtCedula.getText();

            // Nombre del archivo PDF con marca de tiempo y cédula
            String nombreArchivo = "Reporte_" + cedula + ".pdf";

            // Verificar si el archivo ya existe
            File file = new File(nombreArchivo);
            if (file.exists()) {
                JOptionPane.showMessageDialog(this, "Ya se generó un reporte para esta cédula.", "Información", JOptionPane.INFORMATION_MESSAGE);
                limpiarCampos();
                return false;
            }

            // Crea un nuevo documento PDF
            Document document = new Document();
            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(nombreArchivo));

            // Agregar evento para dibujar la marca de agua
            writer.setPageEvent(new WatermarkBackground());

            // Abre el documento para agregar contenido
            document.open();

            // Agregar imagen a la izquierda con espacio adicional
            Image image = Image.getInstance("G:\\ProyectoFinal_Grupo4\\src\\main\\java\\imagenes\\Escudo_Policia_Nacional_Ecuador.jpg");
            image.setAlignment(Image.ALIGN_LEFT); // Alinea la imagen a la izquierda
            image.scaleToFit(170, 100); // Ajusta el tamaño de la imagen

            // Crear el encabezado con logo a la izquierda y texto a la derecha
            Paragraph encabezadoSistema = new Paragraph();
            encabezadoSistema.add(new Chunk(image, 0, -60)); // Ajusta la posición vertical de la imagen
            encabezadoSistema.add(new Chunk("      SISTEMA DE GESTION DE POLICIA", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18, BaseColor.BLACK)));

            // Ajustar posición y centrar
            encabezadoSistema.setAlignment(Element.ALIGN_LEFT); // Alinea el encabezado a la izquierda
            document.add(encabezadoSistema);

            // Agregar encabezado centrado "Reporte Policial"
            Paragraph titulo = new Paragraph("Reporte Policial", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18, BaseColor.BLACK));
            titulo.setAlignment(Element.ALIGN_CENTER);
            document.add(titulo);

            // Agregar fecha centrada con líneas simuladas
            String currentDate = new SimpleDateFormat("dd/MM/yyyy").format(new Date());
            Paragraph fecha = new Paragraph("Fecha: " + currentDate, FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14, BaseColor.BLACK));
            fecha.setAlignment(Element.ALIGN_CENTER);

            Chunk espacios = new Chunk("\n");//Genera un salto línea 
            document.add(espacios);

            // Simular línea azul
            Chunk chunkAzul = new Chunk("_______________________________________________________");
            chunkAzul.setBackground(new BaseColor(0, 51, 153));
            fecha.add(chunkAzul);

            // Simular línea gris
            Chunk chunkGris = new Chunk("_______________________________________________________");
            chunkGris.setBackground(new BaseColor(169, 169, 169));
            fecha.add(chunkGris);

            document.add(fecha);

            Chunk espacio = new Chunk("\n");//Genera un salto línea 
            document.add(espacio);
            // Crear una tabla con dos columnas
            PdfPTable table = new PdfPTable(2);
            table.setWidthPercentage(100);

            // Agregar la información al documento y la tabla
            agregarCeldaATablaJustificada(table, "Nombre:", txtNombre.getText());
            agregarCeldaATablaJustificada(table, "Cédula:", cedula);
            agregarCeldaATablaJustificada(table, "Celular:", txtCelular.getText());
            agregarCeldaATablaJustificada(table, "Fecha de Nacimiento:", new SimpleDateFormat("dd/MM/yyyy").format(choFechaNacimiento.getDate()));
            agregarCeldaATablaJustificada(table, "Categoría:", (String) jComboBox1.getSelectedItem());
            agregarCeldaATablaJustificada(table, "Hora de Entrada:", txtHoraEntrada.getText());
            agregarCeldaATablaJustificada(table, "Hora de Salida:", txtHoraSalida.getText());

            // Verifica si la categoría es "Administrativo"
            if ("Administrativo".equals((String) jComboBox1.getSelectedItem())) {
                agregarCeldaATablaJustificada(table, "Lugar Asignado:", "Instalaciones de la Policía Nacional del Ecuador");
                agregarCeldaATablaJustificada(table, "Upc Asignado:", "Instalaciones de la Policía Nacional del Ecuador");
            } else {
                agregarCeldaATablaJustificada(table, "Lugar Asignado:", (String) jComboBox5.getSelectedItem());
                agregarCeldaATablaJustificada(table, "Upc Asignado:", (String) jComboBox4.getSelectedItem());
            }

            agregarCeldaATablaJustificada(table, "Existió Novedad:", (String) jComboBox2.getSelectedItem());

            // Verifica si la categoría es "No"
            if ("No".equals((String) jComboBox2.getSelectedItem())) {
                agregarCeldaATablaJustificada(table, "Novedad:", "No existieron novedades en el día");
                agregarCeldaATablaJustificada(table, "Descripción:", "No existió ningún percance en el día");
            } else {
                agregarCeldaATablaJustificada(table, "Novedad:", (String) jComboBox3.getSelectedItem());
                agregarCeldaATablaJustificada(table, "Descripción:", jTextArea1.getText());
            }

            // Agregar la tabla al documento
            document.add(table);

            // Cierra el documento
            document.close();

            // Muestra un mensaje de éxito
            JOptionPane.showMessageDialog(this, "Reporte generado exitosamente.", "Información", JOptionPane.INFORMATION_MESSAGE);

            limpiarCampos();

            return true;
        } catch (Exception e) {
            mostrarError("Error al generar el reporte", e);
            return false;
        }
    }

// Clase para manejar el evento de fondo y marca de agua
    public class WatermarkBackground extends PdfPageEventHelper {

        @Override
        public void onEndPage(PdfWriter writer, Document document) {
            PdfContentByte canvas = writer.getDirectContentUnder();
            // Establecer color celeste transparente para el fondo
            BaseColor color = new BaseColor(250, 250, 250, 100); // 100 es la opacidad
            canvas.setColorFill(color);
            canvas.rectangle(0, 0, document.getPageSize().getWidth(), document.getPageSize().getHeight());
            canvas.fill();

            try {
                // Cargar la imagen desde el archivo
                Image image = Image.getInstance("G:\\ProyectoFinal_Grupo4\\src\\main\\java\\imagenes\\Escudo_Policia_Nacional_Ecuador.jpg");

                // Escalar la imagen según tus necesidades
                image.scaleToFit(200, 200); // Ajusta el tamaño de la imagen

                // Establecer la posición de la imagen
                image.setAbsolutePosition(200, 300);

                // Configurar la opacidad de la imagen
                PdfGState gs = new PdfGState();
                gs.setFillOpacity(0.4f); // Valor entre 0 (completamente transparente) y 1 (opacidad completa)
                canvas.setGState(gs);

                // Agregar la imagen al canvas
                canvas.addImage(image);
            } catch (Exception e) {
                e.printStackTrace();
            }

            // Establecer la marca de agua
            Font font = new Font(Font.FontFamily.HELVETICA, 45, Font.BOLD, BaseColor.GRAY);
            Phrase watermark = new Phrase("SISTEMA DE GESTION DE POLICIA", font);

            ColumnText.showTextAligned(canvas, Element.ALIGN_CENTER, watermark, 300, 400, 45);
        }
    }
// Método para agregar celda a la tabla con estilo de fuente personalizado

    private void agregarCeldaEstilizadaATabla(PdfPTable table, String etiqueta, String valor, Font font) {
        PdfPCell celdaEtiqueta = new PdfPCell(new Phrase(etiqueta, font));
        celdaEtiqueta.setBorder(Rectangle.NO_BORDER);

        PdfPCell celdaValor = new PdfPCell(new Phrase(valor, font));
        celdaValor.setBorder(Rectangle.NO_BORDER);

        table.addCell(celdaEtiqueta);
        table.addCell(celdaValor);
    }

// Método para agregar una celda a la tabla con texto justificado
    private void agregarCeldaATablaJustificada(PdfPTable table, String etiqueta, String valor) {
        Font fontEtiqueta = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16, BaseColor.BLACK); // Tamaño 14 y negrita para etiquetas
        Font fontValor = FontFactory.getFont(FontFactory.HELVETICA, 16, BaseColor.BLACK); // Tamaño 14 para valores

        PdfPCell etiquetaCell = new PdfPCell(new Phrase(etiqueta, fontEtiqueta));
        PdfPCell valorCell = new PdfPCell(new Phrase(valor, fontValor));

        // Establecer alineación justificada para el texto
        etiquetaCell.setHorizontalAlignment(Element.ALIGN_JUSTIFIED);
        valorCell.setHorizontalAlignment(Element.ALIGN_JUSTIFIED);

        etiquetaCell.setBorder(Rectangle.BOTTOM);
        valorCell.setBorder(Rectangle.BOTTOM);

        // Establecer color azul oscuro para la línea inferior
        BaseColor colorAzulOscuro = new BaseColor(0, 51, 153);
        etiquetaCell.setBorderColorBottom(colorAzulOscuro);
        valorCell.setBorderColorBottom(colorAzulOscuro);

        table.addCell(etiquetaCell);
        table.addCell(valorCell);
    }

    private void limpiarCampos() {
        // Limpiar los campos aquí, por ejemplo:
        txtNombre.setText("");
        txtCedula.setText("");
        txtCelular.setText("");
        txtHoraEntrada.setText("");
        txtHoraSalida.setText("");
        jComboBox1.setSelectedIndex(0);
        jComboBox2.setSelectedIndex(0);
        jComboBox3.setSelectedIndex(0);
        jComboBox4.setSelectedIndex(0);
        jComboBox5.setSelectedIndex(0);
        jTextArea1.setText("");
    }

    public boolean buscarDatos() {
        try {
            String cedulaABuscar = txtCedula.getText().trim();
            if (cedulaABuscar.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingrese una cédula para buscar.", "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }

            long cedula;
            try {
                cedula = Long.parseLong(cedulaABuscar);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "La cédula debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }

            List<DatosPolicia> resultados = conexion.buscarpoliciaPorCedula(cedulaABuscar);

            if (resultados.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No se encontraron policías con la cédula especificada.", "Información", JOptionPane.INFORMATION_MESSAGE);
                return false;
            }

            DatosPolicia resultado = resultados.get(0);

            // Mostrar resultados en cajas de texto
            txtNombre.setText(resultado.getNombre());
            txtCedula.setText(String.valueOf(resultado.getCedula()));
            txtCelular.setText(String.valueOf(resultado.getCelular()));
            choFechaNacimiento.setDate(new SimpleDateFormat("dd/MM/yyyy").parse(resultado.getFechanacimiento())); // Suponiendo que la fecha está en formato "dd/MM/yyyy"
            jComboBox1.setSelectedItem(resultado.getCategoria());

            // Verificar si la categoría es "Administrativo"
            if ("Administrativo".equals(resultado.getCategoria())) {
                // Si es administrativo, mostrar o bloquear campos según sea necesario

                jComboBox4.setSelectedItem("");  // Seleccionar el valor predeterminado
                jComboBox4.setEnabled(false);  // Puedes deshabilitar la selección
                jComboBox5.setSelectedItem("");
                jComboBox5.setEnabled(false);
            } else {
                // Si no es administrativo, permitir la edición normal de los campos
                jComboBox4.setEnabled(true);
                jComboBox5.setEnabled(true);
            }

            JOptionPane.showMessageDialog(this, "Se encontraron policías con la cédula especificada.", "Información", JOptionPane.INFORMATION_MESSAGE);

            return true;
        } catch (Exception e) {
            mostrarError("Error al buscar datos", e);
            return false;
        }
    }

    private void mostrarError(String mensaje, Exception e) {
        JOptionPane.showMessageDialog(this, mensaje + "\n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jPanel1 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        txtCedula = new javax.swing.JTextField();
        txtCelular = new javax.swing.JTextField();
        choFechaNacimiento = new com.toedter.calendar.JDateChooser();
        jComboBox2 = new javax.swing.JComboBox<>();
        jSeparator4 = new javax.swing.JSeparator();
        jPanel7 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        btnAsignar = new javax.swing.JButton();
        btnMenu1 = new javax.swing.JButton();
        btnBuscar7 = new javax.swing.JButton();
        jSeparator7 = new javax.swing.JSeparator();
        jSeparator8 = new javax.swing.JSeparator();
        jSeparator9 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel29 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox<>();
        jLabel30 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel31 = new javax.swing.JLabel();
        jComboBox4 = new javax.swing.JComboBox<>();
        jComboBox5 = new javax.swing.JComboBox<>();
        txtHoraSalida = new javax.swing.JTextField();
        txtHoraEntrada = new javax.swing.JTextField();

        jMenu1.setText("File");
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        jMenuItem1.setText("jMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel14.setText("Numero de Celular");
        jLabel14.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 160, 200, 20));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel15.setText("Nombre y Apellido:");
        jLabel15.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 130, 200, 20));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel16.setText("Ingrese su numero de cedula");
        jLabel16.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 100, 200, 20));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel17.setText("Fecha de Nacimiento:");
        jLabel17.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 190, 200, 20));

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel18.setText("Categoria");
        jLabel18.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 220, 200, 20));

        txtNombre.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        txtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNombreKeyTyped(evt);
            }
        });
        jPanel1.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 130, 261, 20));

        txtCedula.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        txtCedula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCedulaActionPerformed(evt);
            }
        });
        txtCedula.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCedulaKeyTyped(evt);
            }
        });
        jPanel1.add(txtCedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 100, 261, 20));

        txtCelular.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        txtCelular.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCelularKeyTyped(evt);
            }
        });
        jPanel1.add(txtCelular, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 160, 261, 20));

        choFechaNacimiento.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel1.add(choFechaNacimiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 190, 260, 20));

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Si", "No" }));
        jComboBox2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });
        jPanel1.add(jComboBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 370, 261, 20));

        jSeparator4.setForeground(new java.awt.Color(12, 92, 235));
        jSeparator4.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jPanel1.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 100, 10, 310));

        jPanel7.setBackground(new java.awt.Color(0, 51, 153));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("REPORTE DEL DIA ");
        jPanel7.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 30, -1, 39));

        jPanel1.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 0, 520, 90));

        jPanel6.setBackground(new java.awt.Color(0, 51, 153));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnAsignar.setBackground(new java.awt.Color(0, 51, 153));
        btnAsignar.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btnAsignar.setForeground(new java.awt.Color(255, 255, 255));
        btnAsignar.setText("GENERAR");
        btnAsignar.setBorder(null);
        btnAsignar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAsignarActionPerformed(evt);
            }
        });
        jPanel6.add(btnAsignar, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 310, 120, 30));

        btnMenu1.setBackground(new java.awt.Color(0, 51, 153));
        btnMenu1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btnMenu1.setForeground(new java.awt.Color(255, 255, 255));
        btnMenu1.setText("MENÚ");
        btnMenu1.setBorder(null);
        btnMenu1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMenu1ActionPerformed(evt);
            }
        });
        jPanel6.add(btnMenu1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 360, 80, 30));

        btnBuscar7.setBackground(new java.awt.Color(0, 51, 153));
        btnBuscar7.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btnBuscar7.setForeground(new java.awt.Color(255, 255, 255));
        btnBuscar7.setText("BUSCAR");
        btnBuscar7.setBorder(null);
        btnBuscar7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscar7ActionPerformed(evt);
            }
        });
        jPanel6.add(btnBuscar7, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 260, -1, 30));

        jSeparator7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.add(jSeparator7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 340, 120, 20));

        jSeparator8.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.add(jSeparator8, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 290, 120, 20));

        jSeparator9.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.add(jSeparator9, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 390, 120, 10));

        jLabel1.setForeground(new java.awt.Color(0, 51, 153));
        jLabel1.setIcon(new javax.swing.ImageIcon("G:\\ProyectoFinal_Grupo4\\src\\main\\java\\imagenes\\logopolicia.jpg")); // NOI18N
        jLabel1.setText("jLabel1");
        jPanel6.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 170, 150));

        jPanel1.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 190, 560));

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel22.setText("Hora de entrada");
        jLabel22.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel1.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 250, 200, -1));

        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel23.setText("Hora de Salida ");
        jLabel23.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel1.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 280, 200, -1));

        jLabel27.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel27.setText("Lugar Asignado ");
        jLabel27.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel1.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 310, 200, -1));

        jLabel28.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel28.setText("Existio Novedad");
        jLabel28.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel1.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 370, 200, 20));

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Policial", "Administrativo" }));
        jComboBox1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel1.add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 220, 261, 20));

        jLabel29.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel29.setText("Que novedad existio");
        jLabel29.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel1.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 400, 200, 20));

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Asalto", "Violencia Domestica", "Violencia Laboral", "Allanamiento", "Persona Desaparecida", "No existio ninguna Novedad" }));
        jComboBox3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel1.add(jComboBox3, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 400, 261, 20));

        jLabel30.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel30.setText("Describa lo sucedido ");
        jLabel30.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel1.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 430, 150, 20));

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jTextArea1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 51, 153), new java.awt.Color(255, 255, 255), new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jScrollPane1.setViewportView(jTextArea1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 460, 470, -1));

        jLabel31.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel31.setText("UPC Asignado ");
        jLabel31.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel1.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 340, 200, -1));

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Plan de Vivienda", "Proletariado", "Los Rosales", "Che Guevara", "Juan Eulogio", "Los Unificados", "Ya tiene Ruta Asigando" }));
        jComboBox4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel1.add(jComboBox4, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 340, 260, 20));

        jComboBox5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Coop 2 de Mayo", "Coop Gran Colombia", "Coop 30 de Junio", "Coop 30 de Julio", "Ya tiene UPC asignado" }));
        jComboBox5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel1.add(jComboBox5, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 310, 260, 20));

        txtHoraSalida.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 255, 255), null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        txtHoraSalida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHoraSalidaActionPerformed(evt);
            }
        });
        txtHoraSalida.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtHoraSalidaKeyTyped(evt);
            }
        });
        jPanel1.add(txtHoraSalida, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 280, 260, -1));

        txtHoraEntrada.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 255, 255), null, new java.awt.Color(0, 51, 153), new java.awt.Color(0, 51, 153)));
        jPanel1.add(txtHoraEntrada, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 250, 260, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtNombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreKeyTyped
        char c = evt.getKeyChar();
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == KeyEvent.VK_BACK_SPACE || c == KeyEvent.VK_SPACE)) {
            evt.consume();
        }
    }//GEN-LAST:event_txtNombreKeyTyped

    private void txtCedulaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCedulaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCedulaActionPerformed

    private void txtCedulaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCedulaKeyTyped
        char c = evt.getKeyChar();
        if (!Character.isDigit(c) && c != '.'){
            evt.consume();
        }
    }//GEN-LAST:event_txtCedulaKeyTyped

    private void txtCelularKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCelularKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCelularKeyTyped

    private void btnAsignarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAsignarActionPerformed
        generarreporte();
    }//GEN-LAST:event_btnAsignarActionPerformed

    private void btnMenu1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMenu1ActionPerformed
        // TODO add your handling code here:
        MenuPractica1 menu = new MenuPractica1();
        menu.setVisible(true);
        this.dispose();

    }//GEN-LAST:event_btnMenu1ActionPerformed

    private void btnBuscar7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscar7ActionPerformed
        // TODO add your handling code here:
        buscarDatos();
    }//GEN-LAST:event_btnBuscar7ActionPerformed

    private void txtHoraSalidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHoraSalidaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHoraSalidaActionPerformed

    private void txtHoraSalidaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtHoraSalidaKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHoraSalidaKeyTyped

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        // TODO add your handling code here:
        String selected = (String) jComboBox2.getSelectedItem();
        if (selected.equals("No")) {
            jComboBox3.setEnabled(false);
        } else if (selected.equals("Si")) { 
            jComboBox3.setEnabled(true);
        }
    }//GEN-LAST:event_jComboBox2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ReporteDiario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ReporteDiario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ReporteDiario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ReporteDiario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ReporteDiario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAsignar;
    private javax.swing.JButton btnBuscar7;
    private javax.swing.JButton btnMenu1;
    private com.toedter.calendar.JDateChooser choFechaNacimiento;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JComboBox<String> jComboBox5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField txtCedula;
    private javax.swing.JTextField txtCelular;
    private javax.swing.JTextField txtHoraEntrada;
    private javax.swing.JTextField txtHoraSalida;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables
}
