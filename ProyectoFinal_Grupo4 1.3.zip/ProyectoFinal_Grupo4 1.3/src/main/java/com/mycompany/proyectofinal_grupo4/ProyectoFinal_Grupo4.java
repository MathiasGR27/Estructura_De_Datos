package com.mycompany.proyectofinal_grupo4;


public class ProyectoFinal_Grupo4 {

    public static void main(String[] args) {
        ReporteDiario login = new ReporteDiario();
        login.setVisible(true);
    } 
}
    