package u1lab2_gualpamathias;

public class Producto {
    //Atributos
    String nombre;
    double precio;
    int cantidad;
    
    //Constructor
    public Producto(String nombre, double precio, int cantidad) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }
}
